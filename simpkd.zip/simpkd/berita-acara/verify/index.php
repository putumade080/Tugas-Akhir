<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/notification.php");
    
    $payload = decode_jwt_token(["Kasubag TU", "Kepala UPT", "Staf"], ["Mobile"]);
    $user_id = $payload["id"];
    $role = $payload["role"];
    
    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!isset($_POST["id"], $_POST["status"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }
    
    $id = $_POST["id"];
    $status = intval($_POST["status"]);
    $col = $role == "Kasubag TU" ? "status_kasubagTU" : "status_pegawai";
    $where_col = $role == "Kasubag TU" ? "id_kasubagTU" : "id_staf";
    
    $mysqli = connect_db();
    $query = "
        UPDATE tb_berita_acara ba
        SET ba.$col = ?
        WHERE ba.id = ?
        AND ba.$where_col = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sss", $status, $id, $user_id);
    
    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->close();
    
    if ($role == "Kasubag TU") {
        $query = "
            SELECT p.token_notifikasi 
            FROM tb_pegawai p, tb_berita_acara ba
            WHERE ba.id_staf = p.id
            AND ba.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id);
        
        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }
        
        $stmt->bind_result($notification_token);
        $stmt->fetch();
        $stmt->close();
        
        send_notifications($factory, [$notification_token], [
            "notification_title" => "Berita Acara Kendaraan",
            "notification_message" => "Data baru telah ditambahkan, mohon untuk diverifikasi!",
            "notification_intent" => "news"
        ]);
    }
    
    $response = [
        "status_code" => 200, 
        "data" => null, 
        "message" => "Berita acara berhasil diverifikasi"
    ];
    echo json_encode($response);
    exit();