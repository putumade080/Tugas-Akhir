<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    $payload = decode_jwt_token(["Admin", "Super Admin"], ["Website"]);
    $id_admin = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["id_pegawai"]) && $_POST["id_pegawai"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["status_aktif_surat"]))) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $id_pegawai = $_POST["id_pegawai"];
    $id_kendaraan = $_POST["id_kendaraan"];
    $status_aktif_surat = trim(intval(json_decode($_POST['status_aktif_surat'])));

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*)
        FROM tb_berita_acara b
        WHERE b.status_aktif_surat = 1
        AND b.id_staf = ?
        AND b.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $id_pegawai, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Pegawai sudah terdaftar pada berita acara kendaraan"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_berita_acara b
        WHERE b.status_aktif_surat = 1
        AND b.id_kendaraan = ?
        AND b.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $id_kendaraan, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan sudah terdaftar pada berita acara kendaraan"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT mk.id, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, mk.status_aktif, 
            k.no_stnk, k.no_polisi, k.no_bpkb, k.no_mesin, k.no_rangka, k.no_register_barang, k.warna, 
            k.harga_perolehan, k.tgl_samsat_pertama, k.tgl_berlaku_kir, k.status_aktif, k.status_pemakaian
        FROM tb_kendaraan k, tb_model_kendaraan mk
        WHERE k.id_model = mk.id
        AND k.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_kendaraan);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_model, $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif_model, 
        $no_stnk, $no_polisi, $no_bpkb, $no_mesin, $no_rangka, $no_register_barang, $warna, $harga_perolehan, 
        $tgl_samsat_pertama, $tgl_berlaku_kir, $status_aktif_kendaraan, $status_pemakaian_kendaraan);
    $stmt->fetch();
    $stmt->close();

    if (!$id_model) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kendaraan tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT p.nip, p.nik, p.nama, p.pangkat, p.golongan, p.jenis_kelamin, 
            p.jabatan, p.no_hp, p.alamat, p.role, p.email, p.foto_profil, 
            p.status_ubah_password, p.status_aktif
        FROM tb_pegawai p
        WHERE p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_pegawai);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, 
        $no_hp, $alamat, $role, $email, $foto_profil, $status_ubah_password, $status_aktif);
    $stmt->fetch();
    $stmt->close();

    if (!$nik) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data pegawai tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT p.nip, p.nik, p.nama, p.pangkat, p.golongan, p.jenis_kelamin, 
            p.jabatan, p.no_hp, p.alamat, p.role, p.email, p.foto_profil, 
            p.status_ubah_password, p.status_aktif
        FROM tb_pegawai p
        WHERE (p.role = 'Admin' OR p.role = 'Super Admin')
        AND p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_admin);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($nip_admin, $nik_admin, $nama_admin, $pangkat_admin, $golongan_admin, $jenis_kelamin_admin, $jabatan_admin, 
        $no_hp_admin, $alamat_admin, $role_admin, $email_admin, $foto_profil_admin, $status_ubah_password_admin, $status_aktif_admin);
    $stmt->fetch();
    $stmt->close();

    if (!$nik_admin) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data admin tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT b.id_kendaraan, b.id_kasubagTU, b.no_surat_penggunaan, b.no_surat_serah_terima, b.tanggal, b.status_pegawai, b.status_kasubagTU, b.status_aktif_surat
        FROM tb_berita_acara b
        WHERE b.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_kendaraan_lama, $id_kasubag_tu, $no_surat_penggunaan, $no_surat_serah_terima, $tanggal_surat, $status_pegawai, $status_kasubag_tu, $status_aktif_surat_lama);
    $stmt->fetch();
    $stmt->close();

    if (!$no_surat_penggunaan) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data berita acara tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT p.nip, p.nik, p.nama, p.pangkat, p.golongan, p.jenis_kelamin, 
            p.jabatan, p.no_hp, p.alamat, p.role, p.email, p.foto_profil, 
            p.status_ubah_password, p.status_aktif
        FROM tb_pegawai p
        WHERE p.role = 'Kasubag TU'
        AND p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_kasubag_tu);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($nip_kasubag_tu, $nik_kasubag_tu, $nama_kasubag_tu, $pangkat_kasubag_tu, $golongan_kasubag_tu, $jenis_kelamin_kasubag_tu, $jabatan_kasubag_tu, 
        $no_hp_kasubag_tu, $alamat_kasubag_tu, $role_kasubag_tu, $email_kasubag_tu, $foto_profil_kasubag_tu, $status_ubah_password_kasubag_tu, $status_aktif_kasubag_tu);
    $stmt->fetch();
    $stmt->close();

    if (!$nik_kasubag_tu) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kasubag tu tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    if ($status_pegawai == 1 || $status_kasubag_tu == 1) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data berita acara kendaraan tidak bisa diubah"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (($id_kendaraan != $id_kendaraan_lama || $status_aktif_surat_lama == 0) && $status_pemakaian_kendaraan == 1) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan sedang tidak tersedia"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        UPDATE tb_berita_acara b
        SET b.id_staf = ?,
            b.id_kendaraan = ?,
            b.id_admin = ?,
            b.status_aktif_surat = ?
        WHERE b.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssss", $id_pegawai, $id_kendaraan, $id_admin, $status_aktif_surat, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $query = "UPDATE tb_kendaraan k SET k.status_pemakaian = 0 WHERE k.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_kendaraan_lama);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $query = "UPDATE tb_kendaraan k SET k.status_pemakaian = ? WHERE k.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $status_aktif_surat, $id_kendaraan);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "no_surat" => [$no_surat_penggunaan, $no_surat_serah_terima],
            "tanggal_surat" => $tanggal_surat,
            "status_pegawai" => $status_pegawai,
            "status_kasubag_tu" => $status_kasubag_tu,
            "status_aktif_surat" => boolval($status_aktif_surat),
            "kendaraan" => [
                "id" => $id_kendaraan,
                "model" => [
                    "id" => $id_model,
                    "tipe" => $tipe,
                    "merk" => $merk,
                    "tahun_pembuatan" => $tahun_pembuatan,
                    "isi_silinder" => $isi_silinder,
                    "jumlah_roda" => $jumlah_roda,
                    "status_aktif" => boolval($status_aktif_model)
                ],
                "no_stnk" => $no_stnk,
                "no_polisi" => $no_polisi,
                "no_bpkb" => $no_bpkb,
                "no_mesin" => $no_mesin,
                "no_rangka" => $no_rangka,
                "no_register_barang" => $no_register_barang,
                "warna" => $warna,
                "harga_perolehan" => $harga_perolehan,
                "tgl_samsat_pertama" => $tgl_samsat_pertama,
                "tgl_berlaku_kir" => $tgl_berlaku_kir,
                "status_aktif" => boolval($status_aktif_kendaraan),
                "status_pemakaian" => boolval($status_aktif_surat),
            ],
            "kasubag_tu" => [
                "id" => $id_kasubag_tu,
                "nip" => $nip_kasubag_tu,
                "nik" => $nik_kasubag_tu,
                "nama" => $nama_kasubag_tu,
                "pangkat" => $pangkat_kasubag_tu,
                "golongan" => $golongan_kasubag_tu,
                "jenis_kelamin" => $jenis_kelamin_kasubag_tu,
                "jabatan" => $jabatan_kasubag_tu,
                "no_hp" => $no_hp_kasubag_tu,
                "alamat" => $alamat_kasubag_tu,
                "role" => $role_kasubag_tu,
                "email" => $email_kasubag_tu,
                "foto_profil" => $foto_profil_kasubag_tu,
                "status_ubah_password" => boolval($status_ubah_password_kasubag_tu),
                "status_aktif" => boolval($status_aktif_kasubag_tu), 
            ],
            "pegawai" => [
                "id" => $id_pegawai,
                "nip" => $nip,
                "nik" => $nik,
                "nama" => $nama,
                "pangkat" => $pangkat,
                "golongan" => $golongan,
                "jenis_kelamin" => $jenis_kelamin,
                "jabatan" => $jabatan,
                "no_hp" => $no_hp,
                "alamat" => $alamat,
                "role" => $role,
                "email" => $email,
                "foto_profil" => $foto_profil,
                "status_ubah_password" => boolval($status_ubah_password),
                "status_aktif" => boolval($status_aktif), 
            ],
            "admin" => [
                "id" => $id_admin,
                "nip" => $nip_admin,
                "nik" => $nik_admin,
                "nama" => $nama_admin,
                "pangkat" => $pangkat_admin,
                "golongan" => $golongan_admin,
                "jenis_kelamin" => $jenis_kelamin_admin,
                "jabatan" => $jabatan_admin,
                "no_hp" => $no_hp_admin,
                "alamat" => $alamat_admin,
                "role" => $role_admin,
                "email" => $email_admin,
                "foto_profil" => $foto_profil_admin,
                "status_ubah_password" => boolval($status_ubah_password_admin),
                "status_aktif" => boolval($status_aktif_admin), 
            ]
        ],
        "message" => "Berita acara berhasil diubah"
    ];
    echo json_encode($response);