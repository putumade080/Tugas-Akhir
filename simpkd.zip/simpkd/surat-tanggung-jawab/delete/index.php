<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $mysqli = connect_db();

    $query = "
        UPDATE tb_surat_tanggung_jawab s, tb_detail_surat_tanggung_jawab ds, tb_kendaraan k
        SET s.status_aktif_surat = 0,
            k.status_pemakaian = 0
        WHERE ds.id_surat_tanggung_jawab = s.id
        AND ds.id_kendaraan = k.id
        AND s.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data surat tanggung jawab berhasil dinonaktifkan"
    ];
    echo json_encode($response);