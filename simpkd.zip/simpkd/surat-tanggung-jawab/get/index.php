<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET" || !isset($_GET["id"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $param_id = $_GET["id"];
    $mysqli = connect_db();
    $query = "
        SELECT s.id, pb.id, pb.nip, pb.nik, pb.nama, pb.pangkat, pb.golongan, 
            pb.jenis_kelamin, pb.jabatan, pb.no_hp, pb.alamat, pb.role, pb.email, pb.foto_profil, pb.status_ubah_password, pb.status_aktif, 
            pn.id, pn.nip, pn.nik, pn.nama, pn.pangkat, pn.golongan, pn.jenis_kelamin, pn.jabatan, pn.no_hp, pn.alamat, pn.role, pn.email, pn.foto_profil, pn.status_ubah_password, 
            pn.status_aktif, a.id, a.nip, a.nik, a.nama, a.pangkat, a.golongan, 
            a.jenis_kelamin, a.jabatan, a.no_hp, a.alamat, a.role, a.email, a.foto_profil, a.status_ubah_password, a.status_aktif, 
            s.no_surat, s.tanggal, s.status_pemberi, s.status_penerima, 
            s.status_aktif_surat
        FROM tb_surat_tanggung_jawab s, tb_pegawai pb, tb_pegawai pn, tb_pegawai a
        WHERE s.id_pemberi = pb.id
        AND s.id_penerima = pn.id
        AND s.id_admin = a.id
        AND s.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $param_id);

    if (!$stmt->execute())   {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->bind_result($id, $id_pemberi, $nip_pemberi, $nik_pemberi, $nama_pemberi, $pangkat_pemberi, $golongan_pemberi, $jenis_kelamin_pemberi, 
                    $jabatan_pemberi, $no_hp_pemberi, $alamat_pemberi, $role_pemberi, $email_pemberi, $foto_profil_pemberi, $status_ubah_password_pemberi, $status_aktif_pemberi,
                    $id_pegawai, $nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, $no_hp, $alamat, $role, $email, $foto_profil, $status_ubah_password, $status_aktif,
                    $id_admin, $nip_admin, $nik_admin, $nama_admin, $pangkat_admin, $golongan_admin, $jenis_kelamin_admin, $jabatan_admin, 
                    $no_hp_admin, $alamat_admin, $role_admin, $email_admin, $foto_profil_admin, $status_ubah_password_admin, $status_aktif_admin, $no_surat, $tanggal_surat, 
                    $status_pemberi, $status_penerima, $status_aktif_surat);
                    
    if (!$stmt->fetch()) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->close();
    
    $kendaraan = [];

    $query = "
        SELECT k.id, mk.id, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, mk.status_aktif, 
            k.no_stnk, k.no_polisi, k.no_bpkb, k.no_mesin, k.no_rangka, k.no_register_barang, k.warna, k.harga_perolehan, 
            k.tgl_samsat_pertama, k.tgl_berlaku_kir, k.status_aktif, k.status_pemakaian
        FROM tb_detail_surat_tanggung_jawab ds, tb_kendaraan k, tb_model_kendaraan mk
        WHERE ds.id_kendaraan = k.id
        AND k.id_model = mk.id
        AND ds.id_surat_tanggung_jawab = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_kendaraan, $id_model_kendaraan, $tipe_kendaraan, $merk_kendaraan, 
        $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif_model, $no_stnk, $no_polisi, $no_bpkb, $no_mesin, 
        $no_rangka, $no_register_barang, $warna, $harga_perolehan, $tgl_samsat_pertama, $tgl_berlaku_kir, $status_aktif_kendaraan, $status_pemakaian_kendaraan);
        
    while ($stmt->fetch()) {
        array_push($kendaraan, [
            "id" => $id_kendaraan,
            "model" => [
                "id" => $id_model_kendaraan,
                "tipe" => $tipe_kendaraan,
                "merk" => $merk_kendaraan,
                "tahun_pembuatan" => $tahun_pembuatan,
                "isi_silinder" => $isi_silinder,
                "jumlah_roda" => $jumlah_roda,
                "status_aktif" => boolval($status_aktif_model)
            ],
            "no_stnk" => $no_stnk,
            "no_polisi" => $no_polisi,
            "no_bpkb" => $no_bpkb,
            "no_mesin" => $no_mesin,
            "no_rangka" => $no_rangka,
            "no_register_barang" => $no_register_barang,
            "warna" => $warna,
            "harga_perolehan" => $harga_perolehan,
            "tgl_samsat_pertama" => $tgl_samsat_pertama,
            "tgl_berlaku_kir" => $tgl_berlaku_kir,
            "status_aktif" => boolval($status_aktif_kendaraan),
            "status_pemakaian" => boolval($status_pemakaian_kendaraan),
        ]);
    }
        
    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "no_surat" => $no_surat,
            "tanggal_surat" => $tanggal_surat,
            "status_pemberi" => $status_pemberi,
            "status_penerima" => $status_penerima,
            "status_aktif_surat" => boolval($status_aktif_surat),
            "kendaraan" => $kendaraan,
            "pemberi" => [
                "id" => $id_pemberi,
                "nip" => $nip_pemberi,
                "nik" => $nik_pemberi,
                "nama" => $nama_pemberi,
                "pangkat" => $pangkat_pemberi,
                "golongan" => $golongan_pemberi,
                "jenis_kelamin" => $jenis_kelamin_pemberi,
                "jabatan" => $jabatan_pemberi,
                "no_hp" => $no_hp_pemberi,
                "alamat" => $alamat_pemberi,
                "role" => $role_pemberi,
                "email" => $email_pemberi,
                "foto_profil" => $foto_profil_pemberi,
                "status_ubah_password" => boolval($status_ubah_password_pemberi),
                "status_aktif" => boolval($status_aktif_pemberi), 
            ],
            "penerima" => [
                "id" => $id_pegawai,
                "nip" => $nip,
                "nik" => $nik,
                "nama" => $nama,
                "pangkat" => $pangkat,
                "golongan" => $golongan,
                "jenis_kelamin" => $jenis_kelamin,
                "jabatan" => $jabatan,
                "no_hp" => $no_hp,
                "alamat" => $alamat,
                "role" => $role,
                "email" => $email,
                "foto_profil" => $foto_profil,
                "status_ubah_password" => boolval($status_ubah_password),
                "status_aktif" => boolval($status_aktif), 
            ],
            "admin" => [
                "id" => $id_admin,
                "nip" => $nip_admin,
                "nik" => $nik_admin,
                "nama" => $nama_admin,
                "pangkat" => $pangkat_admin,
                "golongan" => $golongan_admin,
                "jenis_kelamin" => $jenis_kelamin_admin,
                "jabatan" => $jabatan_admin,
                "no_hp" => $no_hp_admin,
                "alamat" => $alamat_admin,
                "role" => $role_admin,
                "email" => $email_admin,
                "foto_profil" => $foto_profil_admin,
                "status_ubah_password" => boolval($status_ubah_password_admin),
                "status_aktif" => boolval($status_aktif_admin)
            ]
        ],
        "message" => "Data Surat Tanggung Jawab berhasil diperoleh"
    ];
    echo json_encode($response);