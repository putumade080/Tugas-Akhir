<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    $payload = decode_jwt_token(["Admin", "Super Admin"], ["Website"]);
    $id_admin = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["id_pemberi"]) && $_POST["id_pemberi"] &&
        isset($_POST["id_penerima"]) && $_POST["id_penerima"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["no_surat"]) && $_POST["no_surat"] &&
        isset($_POST["status_aktif_surat"]))) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $id_pemberi = $_POST["id_pemberi"];
    $id_penerima = $_POST["id_penerima"];
    $id_kendaraan = json_decode($_POST["id_kendaraan"]);
    $no_surat = $_POST["no_surat"];
    $status_aktif_surat = trim(intval(json_decode($_POST['status_aktif_surat'])));

    if (gettype($id_kendaraan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (count($id_kendaraan) == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak boleh kosong"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*)
        FROM tb_pegawai p
        WHERE p.id = ?
    ";

    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_pemberi);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data pemeberi tanggung jawab tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_pegawai p
        WHERE p.id = ?
    ";

    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_penerima);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data penerima tanggung jawab tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_pegawai p
        WHERE (p.role = 'Admin' OR p.role = 'Super Admin')
        AND p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_admin);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data admin tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT s.status_pemberi, s.status_penerima, s.status_aktif_surat
        FROM tb_surat_tanggung_jawab s
        WHERE s.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($status_pemberi, $status_penerima, $status_aktif_surat_lama);
    $stmt->fetch();
    $stmt->close();

    if ($status_pemberi == 1 || $status_penerima == 1) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data surat tanggung jawab tidak bisa diubah"
        ];
        echo json_encode($response);
        exit();
    }
    
    $arr_id_kendaraan_lama = [];

    $query = "SELECT ds.id_kendaraan FROM tb_detail_surat_tanggung_jawab ds WHERE ds.id_surat_tanggung_jawab = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->store_result();
    $stmt->bind_result($id_kendaraan_lama);

    while ($stmt->fetch()) {
        array_push($arr_id_kendaraan_lama, $id_kendaraan_lama);
    }

    $stmt->close();

    for ($i = 0; $i < count($id_kendaraan); $i++) {
        $query = "
            SELECT COUNT(*)
            FROM tb_kendaraan k, tb_model_kendaraan mk
            WHERE k.id_model = mk.id
            AND k.status_pemakaian = 0
            AND k.status_aktif = 1
            AND k.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0 && !in_array($id_kendaraan[$i], $arr_id_kendaraan_lama)) {
            $response = [
                "status_code" => 400,
                "data" => null,
                "message" => "Ada kendaraan yang sedang tidak tersedia"
            ];
            echo json_encode($response);
            exit();
        }
    }

    $query = "
        UPDATE tb_surat_tanggung_jawab s
        SET s.id_pemberi = ?,
            s.id_penerima = ?,
            s.no_surat = ?,
            s.status_aktif_surat = ?
        WHERE s.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssss", $id_pemberi, $id_penerima, $no_surat, $status_aktif_surat, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    foreach ($arr_id_kendaraan_lama as $id_kendaraan_lama) {
        $query = "DELETE FROM tb_detail_surat_tanggung_jawab WHERE id_surat_tanggung_jawab = ? AND id_kendaraan = ?";
        $stmt2 = $mysqli->prepare($query);
        $stmt2->bind_param("ss", $id, $id_kendaraan_lama);

        if (!$stmt2->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt2->close();

        $query = "SELECT k.status_pemakaian FROM tb_kendaraan k WHERE k.id = ?";
        $stmt2 = $mysqli->prepare($query);
        $stmt2->bind_param("s", $id_kendaraan_lama);

        if (!$stmt2->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt2->bind_result($status_pemakaian_kendaraan_lama);
        $stmt2->fetch();
        $stmt2->close();

        if ($status_aktif_surat_lama == 1 && $status_pemakaian_kendaraan_lama == 1) {
            $query = "UPDATE tb_kendaraan k SET k.status_pemakaian = 0 WHERE k.id = ?";
            $stmt2 = $mysqli->prepare($query);
            $stmt2->bind_param("s", $id_kendaraan_lama);

            if (!$stmt2->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }

            $stmt2->close();
        }
    }

    for ($i = 0; $i < count($id_kendaraan); $i++) {
        $query = "
            SELECT COUNT(*)
            FROM tb_kendaraan k, tb_model_kendaraan mk
            WHERE k.id_model = mk.id
            AND k.status_pemakaian = 0
            AND k.status_aktif = 1
            AND k.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            continue;
        }

        $query = "INSERT INTO tb_detail_surat_tanggung_jawab VALUES (NULL, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();

        $query = "UPDATE tb_kendaraan k SET k.status_pemakaian = 1 WHERE k.id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data surat tanggung jawab berhasil diubah"
    ];
    echo json_encode($response);