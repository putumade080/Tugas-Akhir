<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/notification.php");

    $payload = decode_jwt_token(["Admin", "Super Admin"], ["Website"]);
    $id_admin = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!(isset($_POST["id_pemberi"]) && $_POST["id_pemberi"] &&
        isset($_POST["id_penerima"]) && $_POST["id_penerima"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["no_surat"]) && $_POST["no_surat"] &&
        isset($_POST["tanggal_surat"]) && $_POST["tanggal_surat"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id_pemberi = $_POST["id_pemberi"];
    $id_penerima = $_POST["id_penerima"];
    $id_kendaraan = json_decode($_POST["id_kendaraan"]);
    $no_surat = trim($_POST["no_surat"]);
    $tanggal_surat = trim($_POST["tanggal_surat"]);

    if (gettype($id_kendaraan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (count($id_kendaraan) == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak boleh kosong"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tanggal_surat > date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal surat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT p.token_notifikasi
        FROM tb_pegawai p
        WHERE p.id = ?
    ";

    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_pemberi);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($notification_token);
    $stmt->fetch();
    $stmt->close();

    if (!$notification_token) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data pemberi tanggung jawab tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_pegawai p
        WHERE p.id = ?
    ";

    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_penerima);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data penerima tanggung jawab tidak ada"
        ];
        echo json_encode($response);
        exit();
    }
    
    $query = "
        SELECT COUNT(*)
        FROM tb_surat_tanggung_jawab stj
        WHERE stj.status_aktif_surat = 1
        AND stj.id_penerima = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_penerima);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Pegawai sudah terdaftar pada surat tanggung jawab"
        ];
        echo json_encode($response);
        exit();
    }
    
    $query = "
        SELECT COUNT(*)
        FROM tb_berita_acara b
        WHERE b.status_aktif_surat = 1
        AND b.id_staf = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_penerima);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Pegawai sudah terdaftar pada berita acara kendaraan"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_pegawai p
        WHERE (p.role = 'Admin' OR p.role = 'Super Admin')
        AND p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_admin);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data admin tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "INSERT INTO tb_surat_tanggung_jawab VALUES (NULL, ?, ?, ?, ?, ?, 0, 0, 1)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssss", $id_pemberi, $id_penerima, $id_admin, $no_surat, $tanggal_surat);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $mysqli->insert_id;
    $stmt->close();

    for ($i = 0; $i < count($id_kendaraan); $i++) {
        $query = "
            SELECT COUNT(*)
            FROM tb_kendaraan k, tb_model_kendaraan mk
            WHERE k.id_model = mk.id
            AND k.status_pemakaian = 0
            AND k.status_aktif = 1
            AND k.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            continue;
        }

        $query = "INSERT INTO tb_detail_surat_tanggung_jawab VALUES (NULL, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();

        $query = "UPDATE tb_kendaraan k SET k.status_pemakaian = 1 WHERE k.id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }
    
    send_notifications($factory, [$notification_token], [
        "notification_title" => "Surat Tanggung Jawab",
        "notification_message" => "Data baru telah ditambahkan, mohon untuk diverifikasi!",
        "notification_intent" => "letterOfResponsibility"
    ]);

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data surat tanggung jawab berhasil ditambahkan"
    ];
    echo json_encode($response);