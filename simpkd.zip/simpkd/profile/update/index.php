<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/file.php");

    $payload = decode_jwt_token(["Admin", "Super Admin", "Kasubag TU", "PPTK", 
        "Kepala UPT", "Staf"], ["Website", "Mobile"]);
    $id = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["nama"]) && $_POST["nama"] &&
        isset($_POST["jenis_kelamin"]) && $_POST["jenis_kelamin"] &&
        isset($_POST["no_hp"]) && $_POST["no_hp"] &&
        isset($_POST["alamat"]) && $_POST["alamat"] &&
        isset($_POST["email"]) && $_POST["email"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $nama = trim($_POST["nama"]);
    $jenis_kelamin = trim($_POST["jenis_kelamin"]);
    $no_hp = trim($_POST["no_hp"]);
    $alamat = trim($_POST["alamat"]);
    $email = trim(filter_var($_POST["email"], FILTER_SANITIZE_EMAIL));
    

    if ($jenis_kelamin != "L" && $jenis_kelamin != "P") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jenis kelamin tidak boleh kosong"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_hp) < 10 || strlen($no_hp) > 13) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Telepon harus terdiri dari 10-13 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail tidak valid"
        ];
        echo json_encode($response);
        exit();
    }


    $mysqli = connect_db();
    $query = "SELECT p.foto_profil FROM tb_pegawai p WHERE p.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($foto_profil);
    $stmt->fetch();
    $stmt->close();

    if (isset($_FILES["foto_profil"])) {
        $foto_profil = upload_image("foto_profil");
    }

    $query = "
        UPDATE tb_pegawai p
        SET p.nama = ?,
            p.jenis_kelamin = ?,
            p.no_hp = ?,
            p.alamat = ?,
            p.email = ?,
            p.foto_profil = ?
        WHERE p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssss", $nama, $jenis_kelamin, $no_hp, $alamat, $email, $foto_profil, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data diri berhasil diubah"
    ];
    echo json_encode($response);