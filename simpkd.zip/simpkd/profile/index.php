<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    $payload = decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);
    $id = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT p.nip, p.nik, p.nama, p.pangkat, p.golongan, p.jenis_kelamin, p.jabatan, 
            p.no_hp, p.alamat, p.role, p.email, p.foto_profil, p.status_ubah_password, p.status_aktif 
        FROM tb_pegawai p
        WHERE p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, 
        $no_hp, $alamat, $role, $email, $foto_profil, $status_ubah_password, $status_aktif);
    $stmt->fetch();
    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "nip" => $nip,
            "nik" => $nik,
            "nama" => $nama,
            "pangkat" => $pangkat,
            "golongan" => $golongan,
            "jenis_kelamin" => $jenis_kelamin,
            "jabatan" => $jabatan,
            "no_hp" => $no_hp,
            "alamat" => $alamat,
            "role" => $role,
            "email" => $email,
            "foto_profil" => $foto_profil,
            "status_ubah_password" => boolval($status_ubah_password),
            "status_aktif" => boolval($status_aktif)
        ],
        "message" => "Data pegawai berhasil diperoleh"
    ];
    echo json_encode($response);
