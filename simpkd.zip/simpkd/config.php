<?php
    require_once(__DIR__."/vendor/autoload.php");
    require_once(__DIR__."/cors.php");
    require_once(__DIR__."/connection.php");

    use Dotenv\Dotenv;
    use Kreait\Firebase\Factory;

    $res_dir = __DIR__."/res";
    $dotenv = Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    
    $factory = (new Factory)->withServiceAccount(__DIR__."/simpkd-firebase-adminsdk-d6y15-5e12db393d.json");

    date_default_timezone_set('Asia/Makassar');