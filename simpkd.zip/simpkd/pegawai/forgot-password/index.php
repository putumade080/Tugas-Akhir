<?php
    require_once("../../config.php");

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!(isset($_POST["email"]) && $_POST["email"] &&
        isset($_POST["password"]) && $_POST["password"] &&
        isset($_POST["confirm_password"]) && $_POST["confirm_password"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }
    
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];
    
    if ($password != $confirm_password) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Konfirmasi password harus sama dengan password"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    
    $query = "
        UPDATE tb_pegawai p
        SET p.password = ?
        WHERE p.email = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $hash, $email);
    
    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Password baru telah berhasil diubah"
    ];
    echo json_encode($response);