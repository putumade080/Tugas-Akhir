<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/mail.php");

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["email"]) && $_POST["email"]
        && isset($_POST["otp"]) && $_POST["otp"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $otp = $_POST["otp"];

    $mysqli = connect_db();
    $query = "
        SELECT p.id
        FROM tb_pegawai p
        WHERE p.email = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $email);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id);
    $stmt->fetch();
    $stmt->close();

    if (!$id) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail salah"
        ];
        echo json_encode($response);
        exit();
    }
    
    $now = date("Y-m-d H:i:s");
    
    $query = "
        SELECT COUNT(*)
        FROM tb_lupa_password lp
        WHERE lp.id_pegawai = ?
        AND lp.kode = ?
        AND lp.waktu_kadaluarsa > ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sss", $id, $otp, $now);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();
    
    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kode OTP salah atau sudah kadaluarsa"
        ];
        echo json_encode($response);
        exit();
    }
    
    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Request lupa password tervalidasi"
    ];
    echo json_encode($response);