<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/mail.php");

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["email"]) && $_POST["email"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    $mysqli = connect_db();
    $query = "
        SELECT p.id
        FROM tb_pegawai p
        WHERE p.email = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $email);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id);
    $stmt->fetch();
    $stmt->close();

    if (!$id) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail salah"
        ];
        echo json_encode($response);
        exit();
    }
    
    $code = rand(10000, 99999);
    $expired = date("Y-m-d H:i:s", strtotime("+5 minutes"));
    
    $query = "
        SELECT COUNT(*)
        FROM tb_lupa_password lp
        WHERE lp.id_pegawai = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();
    
    if ($total == 0) {
        $query = "INSERT INTO tb_lupa_password VALUES (NULL, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $id, $code, $expired);
    } else {
        $query = "
            UPDATE tb_lupa_password
            SET kode = ?,
                waktu_kadaluarsa = ?
            WHERE id_pegawai = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $code, $expired, $id);
    }
    
    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->close();
    
    $subject = "Kode OTP Lupa Password";
    $message = "Berikut merupakan kode OTP untuk diinputkan pada aplikasi $code";
    
    try {
        send_mail($subject, $email, $message);
    } catch (Exception $e) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: ".$e->getMessage()
        ];
        echo json_encode($response);
        exit();
    }

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Berhasil request lupa password"
    ];
    echo json_encode($response);