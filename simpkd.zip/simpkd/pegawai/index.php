<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $data = [];
    $params = [];

    $mysqli = connect_db();
    $query = "
        SELECT p.id, p.nip, p.nik, p.nama, p.pangkat, p.golongan, p.jenis_kelamin, p.jabatan, 
            p.no_hp, p.alamat, p.role, p.email, p.foto_profil, p.status_ubah_password, p.status_aktif 
        FROM tb_pegawai p
        WHERE TRUE
    ";

    bind_param($params, "status_aktif", $query, "p.status_aktif", true);
    bind_param($params, "role", $query, "p.role", false);
    $stmt = prepare_param($mysqli, $params, $query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id, $nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, 
        $no_hp, $alamat, $role, $email, $foto_profil, $status_ubah_password, $status_aktif);

    while ($stmt->fetch()) {
        array_push($data, [
            "id" => $id,
            "nip" => $nip,
            "nik" => $nik,
            "nama" => $nama,
            "pangkat" => $pangkat,
            "golongan" => $golongan,
            "jenis_kelamin" => $jenis_kelamin,
            "jabatan" => $jabatan,
            "no_hp" => $no_hp,
            "alamat" => $alamat,
            "role" => $role,
            "email" => $email,
            "foto_profil" => $foto_profil,
            "status_ubah_password" => boolval($status_ubah_password),
            "status_aktif" => boolval($status_aktif)
        ]);
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => $data,
        "message" => "Data pegawai berhasil diperoleh"
    ];
    echo json_encode($response);
