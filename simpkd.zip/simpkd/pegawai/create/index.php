<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    $payload = decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["nik"]) && $_POST["nik"] &&
        isset($_POST["nama"]) && $_POST["nama"] &&
        isset($_POST["jenis_kelamin"]) && $_POST["jenis_kelamin"] &&
        isset($_POST["jabatan"]) && $_POST["jabatan"] &&
        isset($_POST["no_hp"]) && $_POST["no_hp"] &&
        isset($_POST["alamat"]) && $_POST["alamat"] &&
        isset($_POST["role"]) && $_POST["role"] &&
        isset($_POST["email"]) && $_POST["email"] &&
        isset($_POST["password"]) && $_POST["password"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $nip = $_POST["nip"] ? trim($_POST["nip"]) : null;
    $nik = trim($_POST["nik"]);
    $nama = trim($_POST["nama"]);
    $pangkat = $_POST["pangkat"] ? trim($_POST["pangkat"]) : null;
    $golongan = $_POST["golongan"] ? trim($_POST["golongan"]) : null;
    $jenis_kelamin = trim($_POST["jenis_kelamin"]);
    $jabatan = trim($_POST["jabatan"]);
    $no_hp = trim($_POST["no_hp"]);
    $alamat = trim($_POST["alamat"]);
    $role = trim($_POST["role"]);
    $email = trim(filter_var($_POST["email"], FILTER_SANITIZE_EMAIL));
    $password = $_POST["password"];
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $foto_profil = $jenis_kelamin == "L" ? "$res_dir/images/avatar_male.png" : "$res_dir/images/avatar_female.png";

    if ($nip && strlen($nip) != 18) {
        $response = [
            "status_code" => 400,
            "data" => $nip,
            "message" => "NIP harus terdiri dari 18 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($nik) != 16) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "NIK harus terdiri dari 16 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if ($jenis_kelamin != "L" && $jenis_kelamin != "P") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jenis kelamin tidak boleh kosong"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_hp) < 10 || strlen($no_hp) > 13) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Telepon harus terdiri dari 10-13 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($password) < 8 || !preg_match("/^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^0-9a-zA-Z ])/", $password)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Password harus minimal 8 karakter dan terdiri dari angka, huruf, serta simbol"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (($payload["role"] == "Admin" && $role == "Admin") || $role == "Super Admin") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Role tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "SELECT COUNT(*) FROM tb_pegawai p WHERE p.nik = ? OR p.email = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $nik, $email);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "NIK atau alamat e-mail sudah dipergunakan"
        ];
        echo json_encode($response);
        exit();
    }
    
    $query = "INSERT INTO tb_pegawai VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 0, 1)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssssssssss", $nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, $no_hp, $alamat, $role, $email, $hash, $foto_profil);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $mysqli->insert_id;
    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "nip" => $nip,
            "nik" => $nik,
            "nama" => $nama,
            "pangkat" => $pangkat,
            "golongan" => $golongan,
            "jenis_kelamin" => $jenis_kelamin,
            "jabatan" => $jabatan,
            "no_hp" => $no_hp,
            "alamat" => $alamat,
            "role" => $role,
            "email" => $email,
            "foto_profil" => $foto_profil,
            "status_ubah_password" => false,
            "status_aktif" => true,
        ],
        "message" => "Data pegawai berhasil ditambahkan"
    ];
    echo json_encode($response);