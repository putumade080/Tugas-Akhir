<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["email"]) && $_POST["email"] &&
        isset($_POST["password"]) && $_POST["password"] &&
        isset($_POST["platform"]) && $_POST["platform"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $platforms = ["Website", "Mobile"];
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];
    $platform = $_POST["platform"];
    $platform_index = array_search($platform, $platforms, true);

    if ($platform_index === false) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Platform tidak tersedia"
        ];
        echo json_encode($response);
        exit();
    }
    
    if ($platform == "Mobile" && !(isset($_POST["notification_token"]) && $_POST["notification_token"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT p.id, p.role, p.password, p.status_ubah_password
        FROM tb_pegawai p
        WHERE p.email = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $email);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id, $role, $hash, $change_password_status);
    $stmt->fetch();
    $stmt->close();

    if (!$id || !password_verify($password, $hash)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail atau kata sandi salah"
        ];
        echo json_encode($response);
        exit();
    }

    $tokens = generate_jwt_token($id, $role, $platform);

    $query = "SELECT COUNT(*) FROM tb_access_token t WHERE t.id_pegawai = ? AND t.platform = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $id, $platform_index);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $query = "
            UPDATE tb_access_token t 
            SET t.token = ? 
            WHERE t.id_pegawai = ? 
            AND t.platform = ?
        ";

        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $tokens["access_token"], $id, $platform_index);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    } else {
        $query = "INSERT INTO tb_access_token VALUES (NULL, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $id, $tokens["access_token"], $platform_index);
    
        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }
    
        $stmt->close();
    }

    $query = "SELECT COUNT(*) FROM tb_refresh_token t WHERE t.id_pegawai = ? AND t.platform = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $id, $platform_index);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $query = "
            UPDATE tb_refresh_token t 
            SET t.token = ? 
            WHERE t.id_pegawai = ? 
            AND t.platform = ?
        ";

        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $tokens["refresh_token"], $id, $platform_index);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    } else {
        $query = "INSERT INTO tb_refresh_token VALUES (NULL, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sss", $id, $tokens["refresh_token"], $platform_index);
    
        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }
    
        $stmt->close();
    }
    
    if ($platform == "Mobile") {
        $notification_token = $_POST["notification_token"];
        $query = "UPDATE tb_pegawai SET token_notifikasi = ? WHERE id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $notification_token, $id);
        
        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }
    
        $stmt->close();
    }

    $response = [
        "status_code" => 200,
        "data" => [
            "access_token" => $tokens["access_token"],
            "refresh_token" => $tokens["refresh_token"],
            "change_password_status" => boolval($change_password_status)
        ],
        "message" => "Berhasil login ke dalam sistem"
    ];
    echo json_encode($response);