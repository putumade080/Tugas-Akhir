<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    $payload = decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf"], ["Mobile"]);
    $id = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!(isset($_POST["password"]) && $_POST["password"] &&
        isset($_POST["confirm_password"]) && $_POST["confirm_password"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }
    
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];
    
    if ($password != $confirm_password) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Konfirmasi password harus sama dengan password"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    
    $query = "
        UPDATE tb_pegawai p
        SET p.password = ?,
            p.status_ubah_password = 1
        WHERE p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $hash, $id);
    
    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Password baru telah berhasil dibuat"
    ];
    echo json_encode($response);