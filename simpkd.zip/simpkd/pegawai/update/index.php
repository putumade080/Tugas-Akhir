<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/file.php");

    $payload = decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["nik"]) && $_POST["nik"] &&
        isset($_POST["nama"]) && $_POST["nama"] &&
        isset($_POST["jenis_kelamin"]) && $_POST["jenis_kelamin"] &&
        isset($_POST["jabatan"]) && $_POST["jabatan"] &&
        isset($_POST["no_hp"]) && $_POST["no_hp"] &&
        isset($_POST["alamat"]) && $_POST["alamat"] &&
        isset($_POST["role"]) && $_POST["role"] &&
        isset($_POST["email"]) && $_POST["email"] &&
        isset($_POST["status_aktif"]))) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $nip = $_POST["nip"] ? trim($_POST["nip"]) : $_POST["nip"];
    $nik = trim($_POST["nik"]);
    $nama = trim($_POST["nama"]);
    $pangkat = $_POST["pangkat"] ? trim($_POST["pangkat"]) : $_POST["pangkat"];
    $golongan = $_POST["golongan"] ? trim($_POST["golongan"]) : $_POST["golongan"];
    $jenis_kelamin = trim($_POST["jenis_kelamin"]);
    $jabatan = trim($_POST["jabatan"]);
    $no_hp = trim($_POST["no_hp"]);
    $alamat = trim($_POST["alamat"]);
    $role = trim($_POST["role"]);
    $email = trim(filter_var($_POST["email"], FILTER_SANITIZE_EMAIL));
    $status_aktif = trim(intval(json_decode($_POST["status_aktif"])));

    if ($nip && strlen($nip) != 18) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "NIP harus terdiri dari 18 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($nik) != 16) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "NIK harus terdiri dari 16 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if ($jenis_kelamin != "L" && $jenis_kelamin != "P") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jenis kelamin tidak boleh kosong"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_hp) < 10 || strlen($no_hp) > 13) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Telepon harus terdiri dari 10-13 angka"
        ];
        echo json_encode($response);
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Alamat e-mail tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "SELECT COUNT(*) FROM tb_pegawai p WHERE (p.nik = ? OR p.email = ?) AND p.id <> ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sss", $nik, $email, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "NIK atau alamat e-mail sudah dipergunakan"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "SELECT p.role, p.foto_profil, p.status_ubah_password FROM tb_pegawai p WHERE p.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($old_role, $foto_profil, $status_ubah_password);
    $stmt->fetch();
    $stmt->close();
    
    if ($payload["id"] != $id && $payload["role"] == "Admin" && in_array($old_role, ["Admin", "Super Admin"])) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Role tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (isset($_FILES["foto_profil"])) {
        $foto_profil = upload_image("foto_profil");
    }

    $query = "
        UPDATE tb_pegawai p
        SET p.nip = ?,
            p.nik = ?,
            p.nama = ?,
            p.pangkat = ?,
            p.golongan = ?,
            p.jenis_kelamin = ?,
            p.jabatan = ?,
            p.no_hp = ?,
            p.alamat = ?,
            p.role = ?,
            p.email = ?,
            p.foto_profil = ?,
            p.status_aktif = ?
        WHERE p.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ssssssssssssss", $nip, $nik, $nama, $pangkat, $golongan, $jenis_kelamin, $jabatan, $no_hp, $alamat, $role, $email, $foto_profil, $status_aktif, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "nip" => $nip,
            "nik" => $nik,
            "nama" => $nama,
            "pangkat" => $pangkat,
            "golongan" => $golongan,
            "jenis_kelamin" => $jenis_kelamin,
            "jabatan" => $jabatan,
            "no_hp" => $no_hp,
            "alamat" => $alamat,
            "role" => $role,
            "email" => $email,
            "foto_profil" => $foto_profil,
            "status_ubah_password" => boolval($status_ubah_password),
            "status_aktif" => boolval($status_aktif)
        ],
        "message" => "Data pegawai berhasil diubah"
    ];
    echo json_encode($response);