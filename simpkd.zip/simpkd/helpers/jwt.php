<?php
    use Firebase\JWT\JWT;

    function generate_jwt_token(int $id, string $role, string $platform) {
        $access_token_payload = [
            "id" => $id,
            "role" => $role,
            "platform" => $platform,
            "iat" => time(),
            "exp" => time() + (15 * 60)
        ];

        $refresh_token_payload = [
            "id" => $id,
            "role" => $role,
            "platform" => $platform,
            "iat" => time()
        ];

        if (!in_array($role, ["Kasubag TU", "PPTK", "Kepala UPT", "Staf"], true)) {
            $refresh_token_payload["exp"] = time() + (3 * 60 * 60);
        }

        $access_token = JWT::encode($access_token_payload, $_ENV["ACCESS_TOKEN_SECRET"]);
        $refresh_token = JWT::encode($refresh_token_payload, $_ENV["REFRESH_TOKEN_SECRET"]);

        return [
            "access_token" => $access_token,
            "refresh_token" => $refresh_token
        ];
    }

    function decode_jwt_token(array $allowed_roles, array $allowed_platforms) {
        if (!isset($_SERVER["HTTP_X_AUTH_TOKEN"])) {
            $response = [
                "status_code" => 401,
                "data" => null,
                "message" => "Mohon masuk terlebih dahulu"
            ];
            echo json_encode($response);
            exit();
        }

        $XAT = explode(" ", $_SERVER["HTTP_X_AUTH_TOKEN"]);
        if (count($XAT) != 2 || $XAT[0] != "Bearer") {
            $response = [
                "status_code" => 401,
                "data" => null,
                "message" => "Akses token tidak valid"
            ];
            echo json_encode($response);
            exit();
        }
        
        $token = $XAT[1];
        $mysqli = connect_db();
        
        try {
            $payload = JWT::decode($token, $_ENV["ACCESS_TOKEN_SECRET"], ["HS256"]);
            $id = $payload->id;
            $role = $payload->role;
            $platform = $payload->platform;
            $platforms = ["Website", "Mobile"];
            $platform_index = array_search($platform, $platforms, true);
            
            if (!in_array($role, $allowed_roles, true) || !in_array($platform, $allowed_platforms, true)) {
                $response = [
                    "status_code" => 401,
                    "data" => null,
                    "message" => "Akses token tidak valid"
                ];
                echo json_encode($response);
                exit();
            }

            $query = "SELECT COUNT(*) FROM tb_access_token t WHERE t.id_pegawai = ? AND t.platform = ?";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("ss", $id, $platform_index);

            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }

            $stmt->bind_result($total);
            $stmt->fetch();
            $stmt->close();

            if ($total == 0) {
                $response = [
                    "status_code" => 401,
                    "data" => null,
                    "message" => "Akses token tidak valid"
                ];
                echo json_encode($response);
                exit();
            }

            return ["id" => $id, "role" => $role, "platform" => $platform];
        } catch (Exception $e) {
            $query = "DELETE FROM tb_access_token WHERE token = ?";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("s", $token);

            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }

            $stmt->close();
            
            $response = [
                "status_code" => 401,
                "data" => null,
                "message" => "Akses token tidak valid"
            ];
            echo json_encode($response);
            exit();
        }
    }