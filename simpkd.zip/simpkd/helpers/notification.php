<?php
    use Kreait\Firebase\Messaging\CloudMessage;
    use Kreait\Firebase\Exception\Messaging\NotFound;
    use Kreait\Firebase\Exception\Messaging\InvalidMessage;
    
    function send_notifications($factory, array $tokens, array $data) {
        $messaging = $factory->createMessaging();
        
        foreach ($tokens as $token) {
            try {
                $message = CloudMessage::withTarget('token', $token)
                    ->withData($data)
                    ->withHighestPossiblePriority();
                $messaging->send($message);
            } catch(NotFound $e) {
                continue;
            } catch(InvalidMessage $e) {
                continue;
            }
        }
    }