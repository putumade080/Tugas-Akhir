<?php
    function bind_param(array &$params, string $name, string &$query, string $col, bool $is_bool = false) {
        if (isset($_GET[$name])) {
            if ($is_bool) {
                $param = intval(json_decode($_GET[$name]));
            } else {
                $param = $_GET[$name];
            }

            $query .= " AND $col = ?";
            array_push($params, $param);
        }
    }

    function prepare_param($mysqli, array $params, string $query) {
        if (count($params) > 0) {
            $param_types = str_repeat("s", count($params));
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param($param_types, ...$params);
        } else {
            $stmt = $mysqli->prepare($query);
        }

        return $stmt;
    }