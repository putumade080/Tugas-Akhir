<?php
    require_once("classes/class.phpmailer.php");
    
    function send_mail($subject, $dest, $message) {
        $mail = new PHPMailer; 
        $mail->IsSMTP();
        $mail->SMTPSecure = 'ssl'; 
        $mail->Host = "simpkd.astungkarasarjana.com";
        $mail->SMTPDebug = 0;
        $mail->Port = 465;
        $mail->SMTPAuth = true;
        $mail->Username = "noreply@simpkd.astungkarasarjana.com";
        $mail->Password = "6qA)~*7f8Asu";
        $mail->SetFrom("noreply@simpkd.astungkarasarjana.com");
        $mail->Subject = $subject;
        $mail->AddAddress($dest);
        $mail->MsgHTML($message);
        
        return $mail->Send();
    }