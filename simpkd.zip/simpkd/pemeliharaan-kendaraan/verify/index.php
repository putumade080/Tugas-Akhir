<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/notification.php");
    
    $payload = decode_jwt_token(["PPTK", "Kasubag TU", "Kepala UPT"], ["Mobile"]);
    $user_id = $payload["id"];
    $role = $payload["role"];
    
    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (!isset($_POST["id"], $_POST["status"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }
    
    $id = $_POST["id"];
    $status = intval($_POST["status"]);
    
    if ($role == "PPTK") {
        $col = "status_pptk";
        $where_col = "id_pptk";
        $next_col = "id_kepalaUPT";
    } elseif ($role == "Kasubag TU") {
        $col = "status_kasubagTU";
        $where_col = "id_kasubagTU";
        $next_col = "id_pptk";
    } else {
        $col = "status_kepalaUPT";
        $where_col = "id_kepalaUPT";
        $next_col = "";
    }
    
    $mysqli = connect_db();
    $query = "
        UPDATE tb_pemeliharaan_kendaraan pk
        SET pk.$col = ?
        WHERE pk.id = ?
        AND pk.$where_col = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sss", $status, $id, $user_id);
    
    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->close();
    
    if ($next_col) {
        $query = "
            SELECT p.token_notifikasi
            FROM tb_pegawai p, tb_pemeliharaan_kendaraan pk
            WHERE pk.$next_col = p.id
            AND pk.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id);
        
        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }
        
        $stmt->bind_result($notification_token);
        $stmt->fetch();
        $stmt->close();
        
        send_notifications($factory, [$notification_token], [
            "notification_title" => "Pemeliharaan Kendaraan",
            "notification_message" => "Data baru telah ditambahkan, mohon untuk diverifikasi!",
            "notification_intent" => "vehicleMaintenance"
        ]);
    }
    
    $response = [
        "status_code" => 200, 
        "data" => null, 
        "message" => "Pemeliharaan kendaraan berhasil diverifikasi"
    ];
    echo json_encode($response);