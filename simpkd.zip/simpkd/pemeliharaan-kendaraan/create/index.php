<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/notification.php");

    $payload = decode_jwt_token(["Staf"], ["Mobile"]);
    $id_staf = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["tanggal"]) && $_POST["tanggal"] &&
        isset($_POST["nomor_surat"]) && $_POST["nomor_surat"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["jenis_kerusakan"]) && $_POST["jenis_kerusakan"] &&
        isset($_POST["jumlah"]) && $_POST["jumlah"] &&
        isset($_POST["keterangan"]) && $_POST["keterangan"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $tanggal = trim($_POST["tanggal"]);
    $nomor_surat = trim($_POST["nomor_surat"]);
    $id_kendaraan = json_decode($_POST["id_kendaraan"]);
    $jenis_kerusakan = json_decode($_POST["jenis_kerusakan"]);
    $jumlah = json_decode($_POST["jumlah"]);
    $keterangan = json_decode($_POST["keterangan"]);

    if (gettype($id_kendaraan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($jenis_kerusakan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jenis kerusakan kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($jumlah) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jumlah kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($keterangan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Keterangan pemeliharaan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (count($jenis_kerusakan) != count($id_kendaraan) || 
        count($jumlah) != count($id_kendaraan) || 
        count($keterangan) != count($id_kendaraan)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    if (!preg_match("/^\d{2}\/\d{3}\/UPTD\.PAL\/\d{4}$/", $nomor_surat)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Surat tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tanggal > date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal surat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "SELECT p.id FROM tb_pegawai p WHERE p.role = 'Kepala UPT' AND p.status_aktif = 1";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_kepalaUPT);
    $stmt->fetch();
    $stmt->close();

    if (!$id_kepalaUPT) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kepala UPT tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "SELECT p.id, p.token_notifikasi FROM tb_pegawai p WHERE p.role = 'Kasubag TU' AND p.status_aktif = 1";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_kasubagTU, $notification_token);
    $stmt->fetch();
    $stmt->close();

    if (!$id_kasubagTU) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kasubag TU tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "SELECT p.id FROM tb_pegawai p WHERE p.role = 'PPTK' AND p.status_aktif = 1";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_pptk);
    $stmt->fetch();
    $stmt->close();

    if (!$id_pptk) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data PPTK tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "SELECT COUNT(*) FROM tb_pegawai p WHERE p.status_aktif = 1 AND p.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_staf);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total == 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data staff tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "INSERT INTO tb_pemeliharaan_kendaraan VALUES (NULL, ?, ?, ?, ?, ?, ?, 0, 0, 0, 1)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ssssss", $id_kepalaUPT, $id_kasubagTU, $id_pptk, $id_staf, $nomor_surat, $tanggal);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $mysqli->insert_id;
    $stmt->close();

    for ($i = 0; $i < count($id_kendaraan); $i++) {
        $query = "
            SELECT 
                (SELECT COUNT(*) FROM tb_berita_acara ba WHERE ba.id_kendaraan = ? AND ba.id_staf = ?) + 
                (SELECT COUNT(*) 
                 FROM tb_surat_tanggung_jawab stj, tb_detail_surat_tanggung_jawab dstj 
                 WHERE stj.id = dstj.id_surat_tanggung_jawab
                 AND stj.id_penerima = ?
                 AND dstj.id_kendaraan = ?)
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ssss", $id_kendaraan[$i], $id_staf, $id_staf, $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            continue;
        }

        $query = "INSERT INTO tb_detail_pemeliharaan VALUES (NULL, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sssss", $id, $id_kendaraan[$i], $jenis_kerusakan[$i], $jumlah[$i], $keterangan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }
    
    send_notifications($factory, [$notification_token], [
        "notification_title" => "Pemeliharaan Kendaraan",
        "notification_message" => "Data baru telah ditambahkan, mohon untuk diverifikasi!",
        "notification_intent" => "vehicleMaintenance"
    ]);

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data pemeliharaan kendaraan berhasil ditambahkan"
    ];
    echo json_encode($response);