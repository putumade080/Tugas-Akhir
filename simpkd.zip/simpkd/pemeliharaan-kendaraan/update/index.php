<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    $payload = decode_jwt_token(["Staf"], ["Mobile"]);
    $id_staf = $payload["id"];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["tanggal"]) && $_POST["tanggal"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["jenis_kerusakan"]) && $_POST["jenis_kerusakan"] &&
        isset($_POST["jumlah"]) && $_POST["jumlah"] &&
        isset($_POST["keterangan"]) && $_POST["keterangan"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $tanggal = trim($_POST["tanggal"]);
    $id_kendaraan = json_decode($_POST["id_kendaraan"]);
    $jenis_kerusakan = json_decode($_POST["jenis_kerusakan"]);
    $jumlah = json_decode($_POST["jumlah"]);
    $keterangan = json_decode($_POST["keterangan"]);

    if (gettype($id_kendaraan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($jenis_kerusakan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jenis kerusakan kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($jumlah) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Jumlah kendaraan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (gettype($keterangan) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Keterangan pemeliharaan tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (count($jenis_kerusakan) != count($id_kendaraan) || 
        count($jumlah) != count($id_kendaraan) || 
        count($keterangan) != count($id_kendaraan)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tanggal > date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal surat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "SELECT pk.status_kepalaUPT, pk.status_kasubagTU, pk.status_pptk FROM tb_pemeliharaan_kendaraan pk WHERE pk.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($status_kepalaUPT, $status_kasubagTU, $status_pptk);
    $stmt->fetch();
    $stmt->close();

    if ($status_kepalaUPT == 1 || $status_kasubagTU == 1 || $status_pptk == 1) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data pemeliharaan kendaraan sudah tidak dapat diubah"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        UPDATE tb_pemeliharaan_kendaraan pk 
        SET pk.tanggal = ?
        WHERE pk.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $tanggal, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $query = "DELETE FROM tb_detail_pemeliharaan WHERE id_pemeliharaan = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    for ($i = 0; $i < count($id_kendaraan); $i++) {
        $query = "
            SELECT 
                (SELECT COUNT(*) FROM tb_berita_acara ba WHERE ba.id_kendaraan = ? AND ba.id_staf = ?) + 
                (SELECT COUNT(*) 
                 FROM tb_surat_tanggung_jawab stj, tb_detail_surat_tanggung_jawab dstj 
                 WHERE stj.id = dstj.id_surat_tanggung_jawab
                 AND stj.id_penerima = ?
                 AND dstj.id_kendaraan = ?)
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ssss", $id_kendaraan[$i], $id_staf, $id_staf, $id_kendaraan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            continue;
        }

        $query = "INSERT INTO tb_detail_pemeliharaan VALUES (NULL, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("sssss", $id, $id_kendaraan[$i], $jenis_kerusakan[$i], $jumlah[$i], $keterangan[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data pemeliharaan kendaraan berhasil diubah"
    ];
    echo json_encode($response);