<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $data = [];
    $params = [];

    $mysqli = connect_db();
    $query = "
        SELECT mk.id, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, mk.status_aktif
        FROM tb_model_kendaraan mk
        WHERE TRUE
    ";

    bind_param($params, "status_aktif", $query, "mk.status_aktif", true);
    $stmt = prepare_param($mysqli, $params, $query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id, $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif);

    while ($stmt->fetch()) {
        array_push($data, [
            "id" => $id,
            "tipe" => $tipe,
            "merk" => $merk,
            "tahun_pembuatan" => $tahun_pembuatan,
            "isi_silinder" => $isi_silinder,
            "jumlah_roda" => $jumlah_roda,
            "status_aktif" => boolval($status_aktif)
        ]);
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => $data,
        "message" => "Data model kendaraan berhasil diperoleh"
    ];
    echo json_encode($response);
