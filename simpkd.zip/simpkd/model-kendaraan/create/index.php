<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["tipe"]) && $_POST["tipe"] &&
        isset($_POST["merk"]) && $_POST["merk"] &&
        isset($_POST["tahun_pembuatan"]) && $_POST["tahun_pembuatan"] &&
        isset($_POST["isi_silinder"]) && $_POST["isi_silinder"] &&
        isset($_POST["jumlah_roda"]) && $_POST["jumlah_roda"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tahun_pembuatan > date("Y")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal samsat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $tipe = trim($_POST["tipe"]);
    $merk = trim($_POST["merk"]);
    $tahun_pembuatan = trim($_POST["tahun_pembuatan"]);
    $isi_silinder = trim($_POST["isi_silinder"]);
    $jumlah_roda = trim($_POST["jumlah_roda"]);

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*)
        FROM tb_model_kendaraan mk
        WHERE mk.tipe = ?
        AND mk.merk = ?
        AND mk.tahun_pembuatan = ?
        AND mk.isi_silinder = ?
        AND mk.jumlah_roda = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssss", $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data model kendaraan sudah ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "INSERT INTO tb_model_kendaraan VALUES (NULL, ?, ?, ?, ?, ?, 1)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssss", $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $mysqli->insert_id;
    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "tipe" => $tipe,
            "merk" => $merk,
            "tahun_pembuatan" => $tahun_pembuatan,
            "isi_silinder" => $isi_silinder,
            "jumlah_roda" => $jumlah_roda,
            "status_aktif" => true
        ],
        "message" => "Data model kendaraan berhasil ditambahkan"
    ];
    echo json_encode($response);