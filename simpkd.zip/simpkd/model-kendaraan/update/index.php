<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["tipe"]) && $_POST["tipe"] &&
        isset($_POST["merk"]) && $_POST["merk"] &&
        isset($_POST["tahun_pembuatan"]) && $_POST["tahun_pembuatan"] &&
        isset($_POST["isi_silinder"]) && $_POST["isi_silinder"] &&
        isset($_POST["jumlah_roda"]) && $_POST["jumlah_roda"] &&
        isset($_POST["status_aktif"]))) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $tipe = trim($_POST["tipe"]);
    $merk = trim($_POST["merk"]);
    $tahun_pembuatan = trim($_POST["tahun_pembuatan"]);
    $isi_silinder = trim($_POST["isi_silinder"]);
    $jumlah_roda = trim($_POST["jumlah_roda"]);
    $status_aktif = trim(intval(json_decode($_POST["status_aktif"])));

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*)
        FROM tb_model_kendaraan mk
        WHERE mk.tipe = ?
        AND mk.merk = ?
        AND mk.tahun_pembuatan = ?
        AND mk.isi_silinder = ?
        AND mk.jumlah_roda = ?
        AND mk.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ssssss", $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data model kendaraan sudah ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        UPDATE tb_model_kendaraan mk
        SET mk.tipe = ?,
            mk.merk = ?,
            mk.tahun_pembuatan = ?,
            mk.isi_silinder = ?,
            mk.jumlah_roda = ?,
            mk.status_aktif = ?
        WHERE mk.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssss", $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "tipe" => $tipe,
            "merk" => $merk,
            "tahun_pembuatan" => $tahun_pembuatan,
            "isi_silinder" => $isi_silinder,
            "jumlah_roda" => $jumlah_roda,
            "status_aktif" => boolval($status_aktif)
        ],
        "message" => "Data model kendaraan berhasil diubah"
    ];
    echo json_encode($response);