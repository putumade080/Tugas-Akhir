<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);
    
    $year = date("Y");
    $mysqli = connect_db();

    $query = "SELECT COUNT(*) FROM tb_berita_acara t WHERE YEAR(t.tanggal) = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $year);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    $letter_count = 2;
    $letter_nums = [];

    for ($i = 1; $i <= $letter_count; $i++) {
        array_push($letter_nums, sprintf("024/%03d/UPTD.PAL-%d", $total * 2 + $i, $year));
    }

    $response = [
        "status_code" => 200,
        "data" => $letter_nums,
        "message" => "Nomor surat berita acara berhasil diperoleh"
    ];
    echo json_encode($response, JSON_UNESCAPED_SLASHES);