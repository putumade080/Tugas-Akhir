<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "PPTK", "Staf", "Super Admin"], ["Mobile"]);
    
    $mysqli = connect_db();

    $query = "SELECT COUNT(*) FROM tb_surat_perintah_tugas spt";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    $letter_num = sprintf("800/%03d/UPTD.PAL-DISPUPR", $total + 1);

    $response = [
        "status_code" => 200,
        "data" => $letter_num,
        "message" => "Nomor surat perintah tugas berhasil diperoleh"
    ];
    echo json_encode($response, JSON_UNESCAPED_SLASHES);