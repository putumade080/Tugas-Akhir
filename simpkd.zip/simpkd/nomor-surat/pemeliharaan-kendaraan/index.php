<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Staf"], ["Mobile"]);
    
    $year = date("Y");
    $mysqli = connect_db();

    $query = "SELECT COUNT(*) FROM tb_pemeliharaan_kendaraan t WHERE YEAR(t.tanggal) = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $year);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    $letter_num = sprintf("27/%03d/UPTD.PAL/%d", $total + 1, $year);

    $response = [
        "status_code" => 200,
        "data" => $letter_num,
        "message" => "Nomor surat pemeliharaan kendaraan berhasil diperoleh"
    ];
    echo json_encode($response, JSON_UNESCAPED_SLASHES);