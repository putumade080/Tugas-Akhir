<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["id_model"]) && $_POST["id_model"] &&
        isset($_POST["no_stnk"]) && $_POST["no_stnk"] &&
        isset($_POST["no_polisi"]) && $_POST["no_polisi"] &&
        isset($_POST["no_bpkb"]) && $_POST["no_bpkb"] &&
        isset($_POST["no_mesin"]) && $_POST["no_mesin"] &&
        isset($_POST["no_rangka"]) && $_POST["no_rangka"] &&
        isset($_POST["no_register_barang"]) && $_POST["no_register_barang"] &&
        isset($_POST["warna"]) && $_POST["warna"] &&
        isset($_POST["harga_perolehan"]) && $_POST["harga_perolehan"] &&
        isset($_POST["tgl_samsat_pertama"]) && $_POST["tgl_samsat_pertama"] &&
        isset($_POST["tgl_berlaku_kir"]) && $_POST["tgl_berlaku_kir"] &&
        isset($_POST["id_alat_monitoring"]) && $_POST["id_alat_monitoring"] &&
        isset($_POST["status_aktif"]) && isset($_POST["status_pemakaian"]))) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $id_model = $_POST["id_model"];
    $no_stnk = trim($_POST["no_stnk"]);
    $no_polisi = trim($_POST["no_polisi"]);
    $no_bpkb = trim($_POST["no_bpkb"]);
    $no_mesin = trim($_POST["no_mesin"]);
    $no_rangka = trim($_POST["no_rangka"]);
    $no_register_barang = trim($_POST["no_register_barang"]);
    $warna = trim($_POST["warna"]);
    $harga_perolehan = trim($_POST["harga_perolehan"]);
    $tgl_samsat_pertama = $_POST["tgl_samsat_pertama"];
    $tgl_berlaku_kir = $_POST["tgl_berlaku_kir"];
    $id_alat_monitoring = $_POST["id_alat_monitoring"];
    $status_aktif = trim(intval(json_decode($_POST["status_aktif"])));
    $status_pemakaian = trim(intval(json_decode($_POST["status_pemakaian"])));

    if (!preg_match("/(^[A-Z]{1,2} \d{1,4}$)|(^[A-Z]{1,2} \d{1,4} [A-Z]{1,3}$)/", $no_polisi)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Polisi tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_stnk) != 12) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. STNK tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_bpkb) < 11 || strlen($no_bpkb) > 13) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. BPKB tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if (strlen($no_rangka) != 17) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Rangka tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tgl_samsat_pertama < date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal samsat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }
    
    if (strlen($id_alat_monitoring) != 16) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "ID alat monitoring tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*) 
        FROM tb_kendaraan k 
        WHERE k.id_alat_monitoring = ?
        AND k.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $id_alat_monitoring, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }
    
    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();
    
    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "ID alat monitoring sudah dipergunakan"
        ];
        echo json_encode($response);
        exit();
    }
    
    $query = "
        SELECT mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, mk.status_aktif
        FROM tb_model_kendaraan mk
        WHERE mk.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_model);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($tipe_model, $merk_model, $tahun_pembuatan_model, $isi_silinder_model, $jumlah_roda_model, $status_aktif_model);
    $stmt->fetch();
    $stmt->close();

    if (!$tipe_model) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data model kendaraan tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT COUNT(*)
        FROM tb_kendaraan k
        WHERE k.no_bpkb = ?
        AND k.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $no_bpkb, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kendaraan sudah ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        UPDATE tb_kendaraan k
        SET k.id_model = ?,
            k.no_stnk = ?,
            k.no_polisi = ?,
            k.no_bpkb = ?,
            k.no_mesin = ?,
            k.no_rangka = ?,
            k.no_register_barang = ?,
            k.warna = ?,
            k.harga_perolehan = ?,
            k.tgl_samsat_pertama = ?,
            k.tgl_berlaku_kir = ?,
            k.id_alat_monitoring = ?,
            k.status_aktif = ?,
            k.status_pemakaian = ?
        WHERE k.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssssssssssss", $id_model, $no_stnk, $no_polisi, $no_bpkb, $no_mesin, $no_rangka, $no_register_barang, $warna, $harga_perolehan, $tgl_samsat_pertama, $tgl_berlaku_kir, $id_alat_monitoring, $status_aktif, $status_pemakaian, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => [
            "id" => $id,
            "no_stnk" => $no_stnk,
            "no_polisi" => $no_polisi,
            "no_bpkb" => $no_bpkb,
            "no_mesin" => $no_mesin,
            "no_rangka" => $no_rangka,
            "no_register_barang" => $no_register_barang,
            "warna" => $warna,
            "harga_perolehan" => $harga_perolehan,
            "tgl_samsat_pertama" => $tgl_samsat_pertama,
            "tgl_berlaku_kir" => $tgl_berlaku_kir,
            "id_alat_monitoring" => $id_alat_monitoring,
            "status_aktif" => true,
            "status_pemakaian" => false,
            "model" => [
                "id" => $id_model,
                "tipe" => $tipe_model,
                "merk" => $merk_model,
                "tahun_pembuatan" => $tahun_pembuatan_model,
                "isi_silinder" => $isi_silinder_model,
                "jumlah_roda" => $jumlah_roda_model,
                "status_aktif" => boolval($status_aktif_model)
            ]
        ],
        "message" => "Data kendaraan berhasil diubah"
    ];
    echo json_encode($response);