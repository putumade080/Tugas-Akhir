<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $data = [];
    $params = [];

    $mysqli = connect_db();
    $query = "
        SELECT k.id, k.id_model, k.no_stnk, k.no_polisi, k.no_bpkb, k.no_mesin, k.no_rangka, k.no_register_barang, k.warna, k.harga_perolehan,
            k.tgl_samsat_pertama, k.tgl_berlaku_kir, k.id_alat_monitoring, k.status_aktif, k.status_pemakaian, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, 
            mk.status_aktif
        FROM tb_kendaraan k, tb_model_kendaraan mk
        WHERE k.id_model = mk.id
    ";

    bind_param($params, "status_aktif", $query, "k.status_aktif", true);
    bind_param($params, "status_pemakaian", $query, "k.status_pemakaian", true);
    bind_param($params, "id_model", $query, "mk.id", false);
    $stmt = prepare_param($mysqli, $params, $query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id, $id_model, $no_stnk, $no_polisi, $no_bpkb, $no_mesin, $no_rangka, $no_register_barang, $warna, $harga_perolehan,
        $tgl_samsat_pertama, $tgl_berlaku_kir, $id_alat_monitoring, $status_aktif, $status_pemakaian, $tipe_model, $merk_model, $tahun_pembuatan_model, $isi_silinder_model, 
        $jumlah_roda_model, $status_aktif_model);

    while ($stmt->fetch()) {
        array_push($data, [
            "id" => $id,
            "no_stnk" => $no_stnk,
            "no_polisi" => $no_polisi,
            "no_bpkb" => $no_bpkb,
            "no_mesin" => $no_mesin,
            "no_rangka" => $no_rangka,
            "no_register_barang" => $no_register_barang,
            "warna" => $warna,
            "harga_perolehan" => $harga_perolehan,
            "tgl_samsat_pertama" => $tgl_samsat_pertama,
            "tgl_berlaku_kir" => $tgl_berlaku_kir,
            "id_alat_monitoring" => $id_alat_monitoring,
            "status_aktif" => boolval($status_aktif),
            "status_pemakaian" => boolval($status_pemakaian),
            "model" => [
                "id" => $id_model,
                "tipe" => $tipe_model,
                "merk" => $merk_model,
                "tahun_pembuatan" => $tahun_pembuatan_model,
                "isi_silinder" => $isi_silinder_model,
                "jumlah_roda" => $jumlah_roda_model,
                "status_aktif" => boolval($status_aktif_model)
            ]
        ]);
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => $data,
        "message" => "Data kendaraan berhasil diperoleh"
    ];
    echo json_encode($response);
