<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    decode_jwt_token(["Admin", "Super Admin"], ["Website"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id"]) && $_POST["id"] &&
        isset($_POST["dasar"]) && $_POST["dasar"] &&
        isset($_POST["tanggal"]) && $_POST["tanggal"] &&
        isset($_POST["status_aktif"]))) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $_POST["id"];
    $dasar = trim($_POST["dasar"]);
    $tanggal = trim($_POST["tanggal"]);
    $status_aktif = trim(intval(json_decode($_POST["status_aktif"])));

    if ($tanggal > date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal samsat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT COUNT(*)
        FROM tb_dasar d
        WHERE d.dasar = ?
        AND d.id <> ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $dasar, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total > 0) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data dasar surat perintah tugas sudah ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
        SELECT d.status_aktif
        FROM tb_dasar d
        WHERE d.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($status_aktif_lama);
    $stmt->fetch();
    $stmt->close();

    if ($status_aktif_lama == 1 && $status_aktif != $status_aktif_lama) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Dasar surat perintah tugas yang sudah aktif tidak bisa di non-aktifkan"
        ];
        echo json_encode($response);
        exit();
    }

    if ($status_aktif == 1) {
        $query = "UPDATE tb_dasar d SET d.status_aktif = 0";
        $stmt = $mysqli->prepare($query);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }

    $query = "
        UPDATE tb_dasar d
        SET d.dasar = ?,
            d.tanggal = ?,
            d.status_aktif = ?
        WHERE d.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ssss", $dasar, $tanggal, $status_aktif, $id);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data dasar surat perintah tugas berhasil diubah"
    ];
    echo json_encode($response);