<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $data = [];
    $params = [];

    $mysqli = connect_db();
    $query = "
        SELECT d.id, d.dasar, d.tanggal, d.status_aktif
        FROM tb_dasar d
        WHERE TRUE
    ";

    bind_param($params, "status_aktif", $query, "d.status_aktif", true);
    $stmt = prepare_param($mysqli, $params, $query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id, $dasar, $tanggal, $status_aktif);

    while ($stmt->fetch()) {
        array_push($data, [
            "id" => $id,
            "dasar" => $dasar,
            "tanggal" => $tanggal,
            "status_aktif" => boolval($status_aktif)
        ]);
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => $data,
        "message" => "Data dasar surat perintah tugas berhasil diperoleh"
    ];
    echo json_encode($response);
