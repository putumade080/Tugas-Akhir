<?php
    header("Content-Type: application/json");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: x-auth-token");