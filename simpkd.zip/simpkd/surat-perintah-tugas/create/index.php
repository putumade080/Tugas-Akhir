<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");
    require_once("../../helpers/file.php");
    require_once("../../helpers/notification.php");

    decode_jwt_token(["Admin", "PPTK", "Staf", "Super Admin"], ["Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!(isset($_POST["id_pemberi_tugas"]) && $_POST["id_pemberi_tugas"] &&
        isset($_POST["id_staf"]) && $_POST["id_staf"] &&
        isset($_POST["id_kendaraan"]) && $_POST["id_kendaraan"] &&
        isset($_POST["no_surat"]) && $_POST["no_surat"] &&
        isset($_POST["tujuan_pemakaian"]) && $_POST["tujuan_pemakaian"] &&
        isset($_POST["tanggal_mulai"]) && $_POST["tanggal_mulai"] &&
        isset($_POST["tanggal_selesai"]) && $_POST["tanggal_selesai"])) {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Mohon lengkapi semua kolom"
        ];
        echo json_encode($response);
        exit();
    }

    $id_pemberi_tugas = $_POST["id_pemberi_tugas"];
    $id_staf = json_decode($_POST["id_staf"]);
    $id_kendaraan = $_POST["id_kendaraan"];
    $no_surat = trim($_POST["no_surat"]);
    $tujuan_pemakaian = trim($_POST["tujuan_pemakaian"]);
    $tanggal_mulai = trim($_POST["tanggal_mulai"]);
    $tanggal_selesai = trim($_POST["tanggal_selesai"]);

    if (gettype($id_staf) != "array") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Staf tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    if (!preg_match("/^\d{3}\/\d{3}\/UPTD\.PAL-DISPUPR$/", $no_surat)) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "No. Surat tidak sesuai"
        ];
        echo json_encode($response);
        exit();
    }

    if ($tanggal_mulai < date("Y-m-d")) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Tanggal surat tidak valid"
        ];
        echo json_encode($response);
        exit();
    }

    $mysqli = connect_db();
    $query = "
        SELECT ds.id, ds.dasar, ds.tanggal, ds.status_aktif
        FROM tb_dasar ds
        WHERE ds.status_aktif = 1
    ";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_dasar_surat, $dasar, $tanggal_dasar, $status_aktif_dasar);
    $stmt->fetch();
    $stmt->close();

    if (!$dasar) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data dasar surat perintah tugas tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "
    SELECT mk.id, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, mk.jumlah_roda, mk.status_aktif, 
    k.no_stnk, k.no_polisi, k.no_bpkb, k.no_mesin, k.no_rangka, k.no_register_barang, k.warna, 
    k.harga_perolehan, k.tgl_samsat_pertama, k.tgl_berlaku_kir, k.status_aktif
    FROM tb_kendaraan k, tb_model_kendaraan mk
    WHERE k.id_model = mk.id
    AND k.id = ?
    ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_kendaraan);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_model, $tipe, $merk, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif_model,
         $no_stnk, $no_polisi, $no_bpkb, $no_mesin, $no_rangka, $no_register_barang, $warna, $harga_perolehan, 
        $tgl_samsat_pertama, $tgl_berlaku_kir, $status_aktif_kendaraan);
    $stmt->fetch();
    $stmt->close();

    if (!$id_model) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kendaraan tidak ada"
        ];
        echo json_encode($response);
        exit();
    }
    
    $query = "SELECT p.token_notifikasi FROM tb_pegawai p WHERE p.status_aktif = 1 AND p.id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_pemberi_tugas);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($notification_token);
    $stmt->fetch();
    $stmt->close();

    if (!$notification_token) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data pemberi tugas tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $query = "SELECT p.id FROM tb_pegawai p WHERE p.role = 'Kasubag TU' AND p.status_aktif = 1";
    $stmt = $mysqli->prepare($query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_result($id_kasubagTU);
    $stmt->fetch();
    $stmt->close();

    if (!$id_kasubagTU) {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Data kasubag TU tidak ada"
        ];
        echo json_encode($response);
        exit();
    }

    $surat_disposisi = upload_image("surat_disposisi");

    $query = "INSERT INTO tb_surat_perintah_tugas VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 1)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssssss", $id_dasar_surat, $id_pemberi_tugas, $id_kasubagTU, $id_kendaraan, $no_surat, $tujuan_pemakaian, $tanggal_mulai, $tanggal_selesai, $surat_disposisi);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $id = $mysqli->insert_id;
    $stmt->close();

    for ($i = 0; $i < count($id_staf); $i++) {
        $query = "
        SELECT COUNT(*) FROM tb_pegawai p WHERE p.status_aktif = 1 AND p.id = ?
        ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $id_staf[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            continue;
        }

        $query = "INSERT INTO tb_detail_surat_perintah_tugas VALUES (NULL, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $id_staf[$i]);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
    }
    
        send_notifications($factory, [$notification_token], [
            "notification_title" => "Surat Perintah Tugas",
            "notification_message" => "Data baru telah ditambahkan, mohon untuk diverifikasi!",
            "notification_intent" => "letterOfTask"
        ]);

    $response = [
        "status_code" => 200,
        "data" => null,
        "message" => "Data Surat Perintah Tugas berhasil ditambahkan"
    ];
    echo json_encode($response);