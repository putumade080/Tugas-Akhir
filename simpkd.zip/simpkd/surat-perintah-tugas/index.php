<?php
    require_once("../config.php");
    require_once("../helpers/param.php");
    require_once("../helpers/jwt.php");

    decode_jwt_token(["Admin", "Kasubag TU", "PPTK", "Kepala UPT", "Staf", "Super Admin"], ["Website", "Mobile"]);

    if ($_SERVER["REQUEST_METHOD"] != "GET") {
        $response = [
            "status_code" => 400, 
            "data" => null, 
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    $data = [];
    $params = [];

    $mysqli = connect_db();
    $query = "
        SELECT spt.id, ds.id, ds.dasar, ds.tanggal, ds.status_aktif, k.id, mk.id, mk.tipe, mk.merk, mk.tahun_pembuatan, mk.isi_silinder, 
                mk.jumlah_roda, mk.status_aktif, k.no_stnk, k.no_polisi, k.no_bpkb, k.no_mesin, k.no_rangka, k.no_register_barang, k.warna, 
                k.harga_perolehan, k.tgl_samsat_pertama, k.status_aktif, k.status_pemakaian, spt.no_surat,  t.id, t.nip, t.nik, t.nama, t.pangkat, 
                t.golongan, t.jenis_kelamin, t.jabatan, t.no_hp, t.alamat, t.role, t.email, t.foto_profil, t.status_ubah_password, t.status_aktif, p.id, p.nip, p.nik, p.nama, p.pangkat, 
                p.golongan, p.jenis_kelamin, p.jabatan, p.no_hp, p.alamat, p.role, p.email, p.foto_profil, p.status_ubah_password, p.status_aktif, 
                spt.tujuan_pemakaian, spt.tanggal_mulai, spt.tanggal_selesai, spt.surat_disposisi, spt.status_pemberi_tugas, spt.status_kasubagTU, spt.status_aktif_surat 
        FROM tb_surat_perintah_tugas spt, tb_dasar ds, tb_kendaraan k, tb_model_kendaraan mk, tb_pegawai t, tb_pegawai p
        WHERE spt.id_dasar_surat = ds.id
        AND spt.id_kendaraan = k.id
        AND k.id_model = mk.id 
        AND spt.id_kasubagTU = t.id
        AND spt.id_pemberi_tugas = p.id
    ";

    bind_param($params, "id_dasar_surat", $query, "spt.id_dasar_surat", false);
    bind_param($params, "id_kendaraan", $query, "spt.id_kendaraan", false);
    bind_param($params, "id_kasubagTU", $query, "spt.id_kasubagTU", false);
    bind_param($params, "status_aktif_surat", $query, "spt.status_aktif_surat", true);
    $query .= " ORDER BY spt.tanggal_mulai DESC";

    $stmt = prepare_param($mysqli, $params, $query);

    if (!$stmt->execute()) {
        $response = [
            "status_code" => 500,
            "data" => null,
            "message" => "Terjadi kesalahan pada server: $mysqli->error"
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->store_result();
    $stmt->bind_result($id, $id_dasar, $dasar_surat, $tanggal_dasar, $status_aktif_dasar, $id_kendaraan, $id_model_kendaraan, $tipe_kendaraan, 
        $merk_kendaraan, $tahun_pembuatan, $isi_silinder, $jumlah_roda, $status_aktif_model, $no_stnk, $no_polisi, $no_bpkb, $no_mesin, 
        $no_rangka, $no_register_barang, $warna, $harga_perolehan, $tgl_samsat_pertama, $status_aktif_kendaraan, $status_pemakaian_kendaraan,
        $no_surat, $id_kasubagTU, $nip_kasubagTU, $nik_kasubagTU, $nama_kasubagTU, $pangkat_kasubagTU, $golongan_kasubagTU, $jenis_kelamin_kasubagTU, 
        $jabatan_kasubagTU, $no_hp_kasubagTU, $alamat_kasubagTU, $role_kasubagTU, $email_kasubagTU, $foto_profil_kasubagTU, 
        $status_ubah_password_kasubagTU, $status_aktif_kasubagTU,
        $id_pemberi_tugas, $nip_pemberi_tugas, $nik_pemberi_tugas, $nama_pemberi_tugas, $pangkat_pemberi_tugas, $golongan_pemberi_tugas, $jenis_kelamin_pemberi_tugas, 
        $jabatan_pemberi_tugas, $no_hp_pemberi_tugas, $alamat_pemberi_tugas, $role_pemberi_tugas, $email_pemberi_tugas, $foto_profil_pemberi_tugas, 
        $status_ubah_password_pemberi_tugas, $status_aktif_pemberi_tugas, $tujuan_pemakaian, $tanggal_mulai, $tanggal_selesai, $surat_disposisi, $status_pemberi_tugas, $status_kasubagTU, 
        $status_aktif_surat);
    

    while ($stmt->fetch()) {
        $staf = [];

        $query = "
            SELECT p.id, p.nip, p.nik, p.nama, p.pangkat, p.golongan,
            p.jenis_kelamin, p.jabatan, p.no_hp, p.alamat, p.role, p.email, p.foto_profil, p.status_ubah_password, 
            p.status_aktif
            FROM tb_pegawai p, tb_detail_surat_perintah_tugas dspt
            WHERE dspt.id_pegawai = p.id
            AND dspt.id_surat_perintah_tugas = ?
        ";
        $stmt2 = $mysqli->prepare($query);
        $stmt2->bind_param("s", $id);

        if (!$stmt2->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt2->bind_result($id_staf, $nip_staf, $nik_staf, $nama_staf, $pangkat_staf, $golongan_staf, 
            $jenis_kelamin_staf, $jabatan_staf, $no_hp_staf, $alamat_staf, $role_staf, $email_staf, $foto_profil_staf, $status_ubah_password_staf, 
            $status_aktif_staf);

        while ($stmt2->fetch()) {
            array_push($staf, [
                "id" => $id_staf,
                "nip" => $nip_staf,
                "nik" => $nik_staf,
                "nama" => $nama_staf,
                "pangkat" => $pangkat_staf,
                "golongan" => $golongan_staf,
                "jenis_kelamin" => $jenis_kelamin_staf,
                "jabatan" => $jabatan_staf,
                "no_hp" => $no_hp_staf,
                "alamat" => $alamat_staf,
                "role" => $role_staf,
                "email" => $email_staf,
                "foto_profil" => $foto_profil_staf,
                "status_ubah_password" => boolval($status_ubah_password_staf),
                "status_aktif" => boolval($status_aktif_staf)
            ]);
        }

        array_push($data, [
            "id" => $id,
            "no_surat" => $no_surat,
            "tujuan_pemakaian" => $tujuan_pemakaian,
            "tanggal_mulai" => $tanggal_mulai,
            "tanggal_selesai" => $tanggal_selesai,
            "surat_disposisi" => $surat_disposisi,
            "status_pemberi_tugas" => $status_pemberi_tugas,
            "status_kasubagTU" => $status_kasubagTU,
            "status_aktif_surat" => boolval($status_aktif_surat),
            "dasar" => [
                "id" => $id_dasar,
                "dasar" => $dasar_surat,
                "tanggal" => $tanggal_dasar,
                "status_aktif" => boolval($status_aktif_dasar), 
            ],
            "kasubagTU" => [
                "id" => $id_kasubagTU,
                "nip" => $nip_kasubagTU,
                "nik" => $nik_kasubagTU,
                "nama" => $nama_kasubagTU,
                "pangkat" => $pangkat_kasubagTU,
                "golongan" => $golongan_kasubagTU,
                "jenis_kelamin" => $jenis_kelamin_kasubagTU,
                "jabatan" => $jabatan_kasubagTU,
                "no_hp" => $no_hp_kasubagTU,
                "alamat" => $alamat_kasubagTU,
                "role" => $role_kasubagTU,
                "email" => $email_kasubagTU,
                "foto_profil" => $foto_profil_kasubagTU,
                "status_ubah_password" => boolval($status_ubah_password_kasubagTU),
                "status_aktif" => boolval($status_aktif_kasubagTU), 
            ],
            "pemberi_tugas" => [
                "id" => $id_pemberi_tugas,
                "nip" => $nip_pemberi_tugas,
                "nik" => $nik_pemberi_tugas,
                "nama" => $nama_pemberi_tugas,
                "pangkat" => $pangkat_pemberi_tugas,
                "golongan" => $golongan_pemberi_tugas,
                "jenis_kelamin" => $jenis_kelamin_pemberi_tugas,
                "jabatan" => $jabatan_pemberi_tugas,
                "no_hp" => $no_hp_pemberi_tugas,
                "alamat" => $alamat_pemberi_tugas,
                "role" => $role_pemberi_tugas,
                "email" => $email_pemberi_tugas,
                "foto_profil" => $foto_profil_pemberi_tugas,
                "status_ubah_password" => boolval($status_ubah_password_pemberi_tugas),
                "status_aktif" => boolval($status_aktif_pemberi_tugas), 
            ],
            "kendaraan" => [
                "id" => $id_kendaraan,
                "model" => [
                    "id" => $id_model_kendaraan,
                    "tipe" => $tipe_kendaraan,
                    "merk" => $merk_kendaraan,
                    "tahun_pembuatan" => $tahun_pembuatan,
                    "isi_silinder" => $isi_silinder,
                    "jumlah_roda" => $jumlah_roda,
                    "status_aktif" => boolval($status_aktif_model)
                ],
                "no_stnk" => $no_stnk,
                "no_polisi" => $no_polisi,
                "no_bpkb" => $no_bpkb,
                "no_mesin" => $no_mesin,
                "no_rangka" => $no_rangka,
                "no_register_barang" => $no_register_barang,
                "warna" => $warna,
                "harga_perolehan" => $harga_perolehan,
                "tgl_samsat_pertama" => $tgl_samsat_pertama,
                "tgl_berlaku_kir" => $tgl_berlaku_kir,
                "status_aktif" => boolval($status_aktif_kendaraan),
                "status_pemakaian" => boolval($status_pemakaian_kendaraan)
            ],
            "staf" => $staf
        ]);
    }

    $stmt->close();

    $response = [
        "status_code" => 200,
        "data" => $data,
        "message" => "Data Surat Perintah Tugas berhasil diperoleh"
    ];
    echo json_encode($response);