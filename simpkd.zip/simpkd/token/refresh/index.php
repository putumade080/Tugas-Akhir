<?php
    require_once("../../config.php");
    require_once("../../helpers/jwt.php");

    use Firebase\JWT\JWT;

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $response = [
            "status_code" => 400,
            "data" => null,
            "message" => "Halaman tidak ditemukan"
        ];
        echo json_encode($response);
        exit();
    }

    if (!isset($_SERVER["HTTP_X_AUTH_TOKEN"])) {
        $response = [
            "status_code" => 401,
            "data" => null,
            "message" => "Mohon masuk terlebih dahulu"
        ];
        echo json_encode($response);
        exit();
    }

    $XAT = explode(" ", $_SERVER["HTTP_X_AUTH_TOKEN"]);
    if (count($XAT) != 2 || $XAT[0] != "Bearer") {
        $response = [
            "status_code" => 401,
            "data" => null,
            "message" => "Refresh token tidak valid"
        ];
        echo json_encode($response);
        exit();
    }
    
    $token = $XAT[1];
    $mysqli = connect_db();
    
    try {
        $payload = JWT::decode($token, $_ENV["REFRESH_TOKEN_SECRET"], ["HS256"]);
        $id = $payload->id;
        $role = $payload->role;
        $platform = $payload->platform;
        $platforms = ["Website", "Mobile"];
        $platform_index = array_search($platform, $platforms, true);

        $query = "SELECT COUNT(*) FROM tb_refresh_token t WHERE t.id_pegawai = ? AND t.platform = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $platform_index);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total == 0) {
            $response = [
                "status_code" => 401,
                "data" => null,
                "message" => "Refresh token tidak valid"
            ];
            echo json_encode($response);
            exit();
        }

        $tokens = generate_jwt_token($id, $role, $platform);
        
        $query = "SELECT COUNT(*) FROM tb_access_token t WHERE t.id_pegawai = ? AND t.platform = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $platform_index);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total > 0) {
            $query = "
                UPDATE tb_access_token t 
                SET t.token = ? 
                WHERE t.id_pegawai = ? 
                AND t.platform = ?
            ";

            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("sss", $tokens["access_token"], $id, $platform_index);

            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }

            $stmt->close();
        } else {
            $query = "INSERT INTO tb_access_token VALUES (NULL, ?, ?, ?)";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("sss", $id, $tokens["access_token"], $platform_index);
        
            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }
        
            $stmt->close();
        }

        $query = "SELECT COUNT(*) FROM tb_refresh_token t WHERE t.id_pegawai = ? AND t.platform = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $id, $platform_index);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        if ($total > 0) {
            $query = "
                UPDATE tb_refresh_token t 
                SET t.token = ? 
                WHERE t.id_pegawai = ? 
                AND t.platform = ?
            ";

            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("sss", $tokens["refresh_token"], $id, $platform_index);

            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }

            $stmt->close();
        } else {
            $query = "INSERT INTO tb_refresh_token VALUES (NULL, ?, ?, ?)";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("sss", $id, $tokens["refresh_token"], $platform_index);
        
            if (!$stmt->execute()) {
                $response = [
                    "status_code" => 500,
                    "data" => null,
                    "message" => "Terjadi kesalahan pada server: $mysqli->error"
                ];
                echo json_encode($response);
                exit();
            }
        
            $stmt->close();
        }

        $response = [
            "status_code" => 200,
            "data" => $tokens,
            "message" => "Sesi berhasil diperbaharui"
        ];
        echo json_encode($response);
    } catch (Exception $e) {
        $query = "DELETE FROM tb_refresh_token WHERE token = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $token);

        if (!$stmt->execute()) {
            $response = [
                "status_code" => 500,
                "data" => null,
                "message" => "Terjadi kesalahan pada server: $mysqli->error"
            ];
            echo json_encode($response);
            exit();
        }

        $stmt->close();
        
        $response = [
            "status_code" => 401,
            "data" => null,
            "message" => "Refresh token tidak valid"
        ];
        echo json_encode($response);
    }