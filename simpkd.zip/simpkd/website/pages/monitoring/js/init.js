let activeId = "";

$(document).ready(async () => {
  const map = L.map("map", {
    center: [-8.409518, 115.188919],
    zoom: 10,
  });

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

  const config = {
    apiKey: "AIzaSyDUpaHl7bMcpfl5AGI_9OnX5ynEpAtRoSQ",
    authDomain: "simpkd.firebaseapp.com",
    databaseURL:
      "https://simpkd-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "simpkd",
    storageBucket: "simpkd.appspot.com",
    messagingSenderId: "692349195081",
    appId: "1:692349195081:web:2b921c2ed16389145ac098",
  };
  firebase.initializeApp(config);
  await getKendaraan();

  const markers = [];

  const ref = firebase.database().ref("/live");
  ref.on("value", (snapshot) => {
    const obj = snapshot.val();

    if (activeId) {
      $("#detail-foto-kendaraan").attr("src", obj[activeId].img);
    }

    markers.map((marker) => map.removeLayer(marker));

    Object.entries(obj).map((data) => {
      const marker = L.marker([data[1].lat, data[1].lng]);
      marker.addTo(map);

      marker
        .bindTooltip(
          () => {
            activeId = data[0];
            const kendaraan = kendaraans.filter(
              (v) => v.id_alat_monitoring === data[0]
            )[0];
            return kendaraan.no_polisi;
          },
          {
            permanent: true,
            direction: "top",
            offset: L.point({ x: -15, y: -15 }),
          }
        )
        .openTooltip();

      marker.on("click", function (e) {
        firebase.database().ref(`/live/${data[0]}`).update({ req: 1 });
        activeId = data[0];
        const kendaraan = kendaraans.filter(
          (v) => v.id_alat_monitoring === data[0]
        )[0];
        $("#detail-no-polisi").html(kendaraan.no_polisi);
        $("#detail-tipe-kendaraan").html(kendaraan.model.tipe);
        $("#detail-merk-kendaraan").html(kendaraan.model.merk);
        $("#detail-kecepatan-kendaraan").html(
          `${Number(data[1].spd).toFixed(2)} km/jam`
        );
        $("#detail-foto-kendaraan").attr("src", data[1].img);
        $("#modal-detail").modal("show");
      });

      markers.push(marker);
    });
  });
});
