$(document).ready(() => {
  $("#tahun-pembuatan").datepicker({
    format: "yyyy",
    viewMode: "years",
    minViewMode: "years",
    todayHighlight: true,
    endDate: new Date(),
  });
  $("#edit-tahun-pembuatan").datepicker({
    format: "yyyy",
    viewMode: "years",
    minViewMode: "years",
    todayHighlight: true,
    endDate: new Date(),
  });
  $("#jenis-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-add"),
    placeholder: "Pilih Jenis Kendaraan",
    allowClear: true,
  });
  $("#edit-jenis-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#edit-status-aktif").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });

  loadingDataTable("dataTable");
  getData();
});

$("#form-add").submit(function (e) {
  e.preventDefault();
  createData();
});

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleEdit = (target) => {
  const data = $(target).parent().data();
  $("#edit-id").val(data.id);
  $("#edit-tipe").val(data.tipe);
  $("#edit-merk").val(data.merk);
  $("#edit-tahun-pembuatan").val(data.tahun_pembuatan);
  $("#edit-isi-silinder").val(data.isi_silinder);
  $("#edit-jenis-kendaraan").val(data.jumlah_roda).trigger("change");
  $("#edit-status-aktif").val(`${data.status_aktif}`).trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};
