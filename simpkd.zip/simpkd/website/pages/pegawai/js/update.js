const updateData = async () => {
  const token = getCookie("act");

  const id = $("#edit-id").val();
  const nama = $("#edit-nama").val();
  const nik = $("#edit-nik").val();
  const jenisKelamin = $("#edit-jenis-kelamin").val();
  const email = $("#edit-email").val();
  const noHP = $("#edit-no-hp").val();
  const alamat = $("#edit-alamat").val();
  const nip = $("#edit-nip").val();
  const jabatan = $("#edit-jabatan").val();
  const pangkat = $("#edit-pangkat").val();
  const golongan = $("#edit-golongan").val();
  const role = $("#edit-role").val();
  const statusAktif = $("#edit-status-aktif").val();
  const fd = new FormData();

  fd.append("id", id);
  fd.append("nip", nip);
  fd.append("nik", nik);
  fd.append("nama", nama);
  fd.append("pangkat", pangkat);
  fd.append("golongan", golongan);
  fd.append("jenis_kelamin", jenisKelamin);
  fd.append("jabatan", jabatan);
  fd.append("no_hp", noHP);
  fd.append("alamat", alamat);
  fd.append("role", role);
  fd.append("email", email);
  fd.append("status_aktif", statusAktif);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pegawai/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-edit").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(updateData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
