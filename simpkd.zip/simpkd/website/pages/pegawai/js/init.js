const roles = ["Kasubag TU", "Kepala UPT", "PPTK", "Staf"];

$(document).ready(async () => {
  loadingDataTable("dataTable");
  await getData();
  if (me.role === "Super Admin") {
    roles.push("Admin");
  }

  roles.map(v => {
    $("#role").append(`<option value="${v}">${v}</option>`)
  })
});

$("#jenis-kelamin").select2({
  theme: "bootstrap4",
  dropdownParent: $("#modal-add"),
  placeholder: "Pilih Jenis Kelamin",
  allowClear: true,
});

$("#role").select2({
  theme: "bootstrap4",
  dropdownParent: $("#modal-add"),
  placeholder: "Pilih Role",
  allowClear: true,
});

$("#edit-jenis-kelamin").select2({
  theme: "bootstrap4",
  dropdownParent: $("#modal-edit"),
});

$("#edit-role").select2({
  theme: "bootstrap4",
  dropdownParent: $("#modal-edit"),
});

$("#edit-status-aktif").select2({
  theme: "bootstrap4",
  dropdownParent: $("#modal-edit"),
});

$("#form-add").submit(function (e) {
  e.preventDefault();
  createData();
});

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleEdit = (target) => {
  const data = $(target).parent().data();
  $("#edit-id").val(data.id);
  $("#edit-nama").val(data.nama);
  $("#edit-nik").val(data.nik);
  $("#edit-jenis-kelamin").val(data.jenis_kelamin).trigger("change");
  $("#edit-email").val(data.email);
  $("#edit-no-hp").val(data.no_hp);
  $("#edit-alamat").val(data.alamat);
  $("#edit-nip").val(data.nip);
  $("#edit-jabatan").val(data.jabatan);
  $("#edit-pangkat").val(data.pangkat);
  $("#edit-golongan").val(data.golongan);
  $("#edit-role").val(data.role).trigger("change");
  $("#edit-status-aktif").val(`${data.status_aktif}`).trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};
