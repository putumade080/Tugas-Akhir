const createData = async () => {
  const token = getCookie("act");

  const nama = $("#nama").val();
  const nik = $("#nik").val();
  const jenisKelamin = $("#jenis-kelamin").val();
  const email = $("#email").val();
  const password = $("#password").val();
  const noHP = $("#no-hp").val();
  const alamat = $("#alamat").val();
  const nip = $("#nip").val();
  const jabatan = $("#jabatan").val();
  const pangkat = $("#pangkat").val();
  const golongan = $("#golongan").val();
  const role = $("#role").val();
  const fd = new FormData();

  fd.append("nip", nip);
  fd.append("nik", nik);
  fd.append("nama", nama);
  fd.append("pangkat", pangkat);
  fd.append("golongan", golongan);
  fd.append("jenis_kelamin", jenisKelamin);
  fd.append("jabatan", jabatan);
  fd.append("no_hp", noHP);
  fd.append("alamat", alamat);
  fd.append("role", role);
  fd.append("email", email);
  fd.append("password", password);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pegawai/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add").modal("hide");
      $("#modal-add .form-control").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
