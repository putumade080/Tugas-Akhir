$(document).ready(() => {
  getData();
});

$("#btn-save").click(function () {
  updateData();
});

$("#avatar").change(function (e) {
  if (e.currentTarget.files.length > 0) {
    const fr = new FileReader()
    fr.onload = () => {
      $("#foto-profil").attr("src", fr.result)
    }
    fr.readAsDataURL(e.currentTarget.files[0])
  }
});