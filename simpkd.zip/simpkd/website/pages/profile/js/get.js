const getData = async () => {
  const token = getCookie("act");

  const req = await fetch(`https://simpkd.astungkarasarjana.com/profile/`, {
    headers: {
      "x-auth-token": `Bearer ${token}`,
    },
  });
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    $("#edit-nama").val(data.nama);
    $("#edit-jenis-kelamin").val(data.jenis_kelamin);
    $("#nip").val(data.nip);
    $("#jabatan").val(data.jabatan);
    $("#pangkat").val(data.pangkat);
    $("#golongan").val(data.golongan);
    $("#edit-email").val(data.email);
    $("#edit-no-hp").val(data.no_hp);
    $("#edit-alamat").val(data.alamat);
    if (data.foto_profil) $("#foto-profil").attr("src", data.foto_profil);
  } else if (status_code === 401) {
    refreshToken(getData);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getData();
    });
  }
};
