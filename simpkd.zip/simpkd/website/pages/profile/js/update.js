const updateData = async () => {
  const token = getCookie("act");

  const nama = $("#edit-nama").val();
  const jenisKelamin = $("#edit-jenis-kelamin").val();
  const email = $("#edit-email").val();
  const noHP = $("#edit-no-hp").val();
  const alamat = $("#edit-alamat").val();
  const foto_profil = $("#avatar")[0].files;
  const fd = new FormData();

  fd.append("nama", nama);
  fd.append("jenis_kelamin", jenisKelamin);
  fd.append("no_hp", noHP);
  fd.append("alamat", alamat);
  fd.append("email", email);

  if (foto_profil.length > 0) {
    fd.append("foto_profil", foto_profil[0]);
  }

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/profile/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    });
  } else if (status_code === 401) {
    refreshToken(updateData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
