let email = "";

$("#form-request").submit(async (e) => {
  e.preventDefault();
  email = $("#email").val();

  if ($("#email").siblings(".validate-helper").text()) {
    Swal.fire({
      title: "Peringatan",
      text: "Mohon lengkapi semua kolom dengan data yang benar",
      icon: "warning",
      confirmButtonText: "Tutup",
    });
    return;
  }

  const fd = new FormData();
  fd.append("email", email);

  const response = await fetch(
    "https://simpkd.astungkarasarjana.com/pegawai/request-forgot-password/",
    {
      method: "POST",
      body: fd,
    }
  );
  const { status_code, message } = await response.json();

  if (status_code === 200) {
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-forgot").modal("show");
    });
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
});

$("#form-forgot").submit(async (e) => {
  e.preventDefault();

  let otp = "";
  otp += $("#otp-1").val();
  otp += $("#otp-2").val();
  otp += $("#otp-3").val();
  otp += $("#otp-4").val();
  otp += $("#otp-5").val();

  const newPassword = $("#password_baru").val();
  const confirmPassword = $("#konfirmasi_password").val();

  if (otp.length !== 5) {
    Swal.fire({
      title: "Peringatan",
      text: "Kode OTP salah",
      icon: "warning",
      confirmButtonText: "Tutup",
    });
    return;
  }

  if (newPassword !== confirmPassword) {
    Swal.fire({
      title: "Peringatan",
      text: "Password baru dan konfirmasi password tidak sama",
      icon: "warning",
      confirmButtonText: "Tutup",
    });
    return;
  }

  const otpFd = new FormData();
  otpFd.append("email", email);
  otpFd.append("otp", otp);

  const responseOTP = await fetch(
    "https://simpkd.astungkarasarjana.com/pegawai/validate-forgot-password/",
    {
      method: "POST",
      body: otpFd,
    }
  );
  const otpJson = await responseOTP.json();

  if (otpJson.status_code === 200) {
    const fd = new FormData();
    fd.append("email", email);
    fd.append("password", newPassword);
    fd.append("confirm_password", confirmPassword);

    const response = await fetch(
      "https://simpkd.astungkarasarjana.com/pegawai/forgot-password/",
      {
        method: "POST",
        body: fd,
      }
    );
    const { status_code, message } = await response.json();

    if (status_code === 200) {
      Swal.fire({
        title: "Berhasil",
        text: message,
        icon: "success",
        confirmButtonText: "Tutup",
      }).then(() => {
        $("#modal-forgot").modal("hide");
        window.location.href = "/website/pages/login/";
      });
    } else {
      Swal.fire({
        title: `Error ${status_code}`,
        text: message,
        icon: status_code === 400 ? "warning" : "error",
        confirmButtonText: "Tutup",
      });
    }
  } else {
    Swal.fire({
      title: `Error ${otpJson.status_code}`,
      text: otpJson.message,
      icon: otpJson.status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
});

$(".otp").keydown((e) => {
    if (e.keyCode != 8 && (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 37 || e.keyCode > 40)) {
        e.preventDefault();
    } else if (e.keyCode >= 48 && e.keyCode <= 57 && e.target.value.length > 0) {
        e.preventDefault();
    } else if ((e.keyCode === 8 && e.target.value.length === 0) || e.keyCode === 37) {
        $(e.target).prev().focus()
    } else if (e.keyCode === 39) {
        $(e.target).next().focus()
    }
})

$(".otp").keyup((e) => {
    if (e.keyCode >= 48 && e.keyCode <= 57) {
        if (e.target.value) {
            e.target.value = e.key
        }
        $(e.target).next().focus()
    } else if (e.keyCode === 8) {
        e.target.value = ""
    }
})