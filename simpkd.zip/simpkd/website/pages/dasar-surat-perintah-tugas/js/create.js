const createData = async () => {
  const token = getCookie("act");

  const dasar = $("#dasar").val();
  const tanggal = $("#tanggal").val();
  const fd = new FormData();

  fd.append("dasar", dasar);
  fd.append("tanggal", tanggal);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/dasar-surat-perintah-tugas/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add").modal("hide");
      $("#modal-add .form-control").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
