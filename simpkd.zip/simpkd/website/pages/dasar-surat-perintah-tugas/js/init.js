$(document).ready(() => {
    $("#tanggal").datepicker({
      format: "yyyy-mm-dd",
      todayHighlight: true,
      endDate: new Date(),
    });
    $("#edit-tanggal").datepicker({
        format: "yyyy-mm-dd",
        todayHighlight: true,
        endDate: new Date(),
      });

      $("#edit-status-aktif").select2({
        theme: "bootstrap4",
        dropdownParent: $("#modal-edit"),
      });

    loadingDataTable("dataTable");
    getData();
  });

  $("#form-add").submit(function (e) {
    e.preventDefault();
    createData();
  });

  $("#form-edit").submit(function (e) {
    e.preventDefault();
    updateData();
  });

  const handleEdit = (target) => {
    const data = $(target).parent().data();
    $("#edit-id").val(data.id);
    $("#edit-dasar").val(data.dasar);
    $("#edit-tanggal").val(data.tanggal);
    $("#edit-status-aktif").val(`${data.status_aktif}`).trigger("change");
};
