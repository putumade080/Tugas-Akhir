const statusBadges = ["badge-warning", "badge-success", "badge-danger"];

const getData = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/dasar-surat-perintah-tugas/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    const tableData = data.map((v, i) => [
      i + 1,
      v.dasar,
      v.tanggal,
      `<span class="p-2 badge badge-pill ${
        v.status_aktif ? "badge-success" : "badge-danger"
      }">${v.status_aktif ? "Aktif" : "Nonaktif"}</span>`,
      `<div class="d-flex">
          <button
            class="btn btn-warning mr-1"
            title="Edit Data Berita Acara Kendaraan"
            data-toggle="modal"
            data-target="#modal-edit"
            onclick="handleEdit(this)"
          >
            <i class="fas fa-edit"></i>
            </button>
        </div>`,
    ]);
    setupFilterDataTable("dataTable", [4], tableData);
    insertDataFilterDataTable("dataTable", data);
  } else if (status_code === 401) {
    refreshToken(getData);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getData();
    });
  }
};
