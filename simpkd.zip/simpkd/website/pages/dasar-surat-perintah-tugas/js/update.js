const updateData = async () => {
  const token = getCookie("act");

  const id = $("#edit-id").val();
  const dasar = $("#edit-dasar").val();
  const tanggal = $("#edit-tanggal").val();
  const status_aktif = $("#edit-status-aktif").val();
  const fd = new FormData();

  fd.append("id", id);
  fd.append("dasar", dasar);
  fd.append("tanggal", tanggal);
  fd.append("status_aktif", status_aktif);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/dasar-surat-perintah-tugas/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-edit").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
