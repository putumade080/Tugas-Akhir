let activeId = "";

$(document).ready(async () => {
  const map = L.map("map", {
    center: [-8.409518, 115.188919],
    zoom: 10,
  });

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

  const config = {
    apiKey: "AIzaSyDUpaHl7bMcpfl5AGI_9OnX5ynEpAtRoSQ",
    authDomain: "simpkd.firebaseapp.com",
    databaseURL:
      "https://simpkd-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "simpkd",
    storageBucket: "simpkd.appspot.com",
    messagingSenderId: "692349195081",
    appId: "1:692349195081:web:2b921c2ed16389145ac098",
  };
  firebase.initializeApp(config);

  const ref = firebase.database().ref("/history");
  let markers = {};

  await getKendaraan();
  
  const showTimestampCheckboxes = () => {
    $('.time-container').html('')
    let children = ""
        
    Object.keys(markers).map(item => {
        children += `<label style="display: block"><input type="checkbox" class="time-item" />${item}</label>`
    })
    
    if (children) {
        children += '<button type="button" class="btn btn-primary time-btn">Tampilkan Semua</button>'
    }
    
    $(".time-container").html(children)
    
    $(".time-btn").click(() => {
        $(".time-item").prop("checked", true).change()
    })
    
    $(".time-item").change((e) => {
        key = $(e.target).parent().text()
        
        if (e.target.checked) {
            markers[key].addTo(map)
        } else {
            map.removeLayer(markers[key])
        }
    })
  }

  $("#kendaraan").select2({
    theme: "bootstrap4",
    placeholder: "Pilih Kendaraan",
    allowClear: true,
  });

  $("#kendaraan").html("<option></option>");
  kendaraans.map((v) =>
    $("#kendaraan").append(
      `<option value="${v.id}">${v.no_polisi} - ${v.model.tipe} - ${v.model.merk}</option>`
    )
  );

  $("#kendaraan").change(() => {
    const selectedVehicle = $("#kendaraan").val();
    Object.values(markers).map(marker => map.removeLayer(marker))
    markers = {}

    if (!selectedVehicle) return;

    const kendaraan = kendaraans.filter(
      (v) => v.id === Number(selectedVehicle)
    )[0];

    ref.get().then((snapshot) => {
      const objects = snapshot.val();

      Object.entries(objects).map((obj) => {
        if (kendaraan.id_alat_monitoring !== obj[0]) return;

        Object.values(obj[1]).map((data) => {
          if (data.lat === 0 || data.lng === 0) {
              return
          }
          
          const marker = L.marker([data.lat, data.lng]);
          const date = new Date(data.timestamp);
          const timestamp = `${String(date.getDate()).padStart(2, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}`;
          
          marker
            .bindTooltip(
              () => `<h6 style="margin: 0; font-weight: 700">${timestamp}</h6>`,
              {
                permanent: true,
                direction: "top",
                offset: L.point({ x: -15, y: -15 }),
              }
            )
            .openTooltip();

          markers[timestamp] = marker
        });
      });
      
      showTimestampCheckboxes()
    });
  });

  ref.on("value", (snapshot) => {
    const objects = snapshot.val();
    const selectedVehicle = $("#kendaraan").val();
    Object.values(markers).map(marker => map.removeLayer(marker))
    markers = {}

    if (!selectedVehicle) return;

    const kendaraan = kendaraans.filter(
      (v) => v.id === Number(selectedVehicle)
    )[0];

    Object.entries(objects).map((obj) => {
      if (kendaraan.id_alat_monitoring !== obj[0]) return;

      Object.values(obj[1]).map((data) => {
        if (data.lat === 0 || data.lng === 0) {
            return
        }
        
        const marker = L.marker([data.lat, data.lng]);
        const date = new Date(data.timestamp);
        const timestamp = `${String(date.getDate()).padStart(2, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}`;
          
        marker.bindTooltip(
          () => `<h6 style="margin: 0; font-weight: 700">${timestamp}</h6>`,
          {
            permanent: true,
            direction: "top",
            offset: L.point({ x: -15, y: -15 }),
          }
        ).openTooltip();

        markers[timestamp] = marker
      });
    });
    
    showTimestampCheckboxes()
  });
});
