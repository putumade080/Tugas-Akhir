const statuses = ["Menunggu Konfirmasi", "Diterima", "Ditolak"];
const statusBadges = ["badge-warning", "badge-success", "badge-danger"];

const getData = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/surat-perintah-tugas/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    const tableData = data.map((v, i) => [
      i + 1,
      v.no_surat,
      `DPPA No : ${v.dasar.dasar} tanggal ${v.dasar.tanggal}`,
      v.pemberi_tugas.nama,
      v.tujuan_pemakaian,
      v.tanggal_mulai,
      v.tanggal_selesai,
      v.kendaraan.no_polisi,
      `<span class="p-2 badge badge-pill ${
        statusBadges[v.status_pemberi_tugas]
      }">${statuses[v.status_pemberi_tugas]}</span>`,
      `<span class="p-2 badge badge-pill ${statusBadges[v.status_kasubagTU]}">${
        statuses[v.status_kasubagTU]
      }</span>`,
      `<span class="p-2 badge badge-pill ${
        v.status_aktif_surat ? "badge-success" : "badge-danger"
      }">${v.status_aktif_surat ? "Aktif" : "Nonaktif"}</span>`,
      `<div class="d-flex">
            <button
            class="btn btn-success mr-1"
            title="Surat Disposisi"
            data-toggle="modal"
            data-target="#modal-disposisi"
            onclick="handleDisposisi(this)"
            >
            <i class="fas fa-images"></i>
            </button>
            <button
            class="btn btn-primary mr-1"
            title="Detail Data Surat Perintah Tugas"
            data-toggle="modal"
            data-target="#modal-detail"
            onclick="handleDetail(this)"
            >
            <i class="fas fa-info-circle"></i>
            </button>
            <button
              class="btn btn-warning mr-1"
              title="Edit Data Surat Perintah Tugas"
              data-toggle="modal"
              data-target="#modal-edit"
              onclick="handleEdit(this)"
            >
              <i class="fas fa-edit"></i>
              </button>
            <button
            class="btn btn-danger mr-1"
            title="Non-Aktif Surat Perintah Tugas"
            data-toggle="modal"
            data-target="#modal-delete"
            onclick="handleDelete(this)"
        >
            <i class="fas fa-file-export"></i>
            </button>
            <a
            class="btn btn-dark"
            title="Print Surat Perintah Tugas"
            href="${window.location.href}/pdf?id=${v.id}"
            >
            <i class="fas fa-print"></i>
            </a>
        </div>`,
    ]);
    setupFilterDataTable("dataTable", [11], tableData);
    insertDataFilterDataTable("dataTable", data);
  } else if (status_code === 401) {
    refreshToken(getData);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getData();
    });
  }
};
