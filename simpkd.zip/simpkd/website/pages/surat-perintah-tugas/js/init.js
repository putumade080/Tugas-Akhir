$(document).ready(() => {
  $("#edit-status-aktif-surat").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });

  loadingDataTable("dataTable");
  getData();
});

const handleDisposisi = (target) => {
  const data = $(target).parent().data();
  const ext = data.surat_disposisi.slice(-3);
  const url =
    ext === "pdf"
      ? `https://drive.google.com/viewerng/viewer?embedded=true&url=${data.surat_disposisi}`
      : data.surat_disposisi;

  if (ext === "pdf") {
    $("#gambar-surat-disposisi").hide();
    $("#frame-surat-disposisi").show();
    $("#frame-surat-disposisi").attr("src", url);
  } else {
    $("#frame-surat-disposisi").hide();
    $("#gambar-surat-disposisi").show();
    $("#gambar-surat-disposisi").attr("src", url);
  }
};

const handleDetail = (target) => {
  const data = $(target).parent().data();

  $("#form-detail .modal-body-slider").html("");

  data.staf.map((v, i) => {
    const detailStaf = `
      <div class="modal-body-item ${i === 0 ? "active" : ""}">
        <h6 class="h6 font-weight-bold text-primary">
          Detail Surat Perintah Tugas
        </h6>
        <span>Berikut merupakan detail data surat perintah tugas tersebut</span>
        <p class="mt-1 text-danger"></p>
        <div class="form-group">
          <label class="detail-form" for="detail-nik"
            >NIK</label
          >
          <div class="form-control" id="detail-nik">${v.nik}</div>
          <p class="validate-helper"></p>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-nama"
            >Nama</label
          >
          <div class="form-control" id="detail-nama">${v.nama}</div>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-jabatan"
            >Jabatan</label
          >
          <div class="form-control" id="detail-jabatan">${v.jabatan}</div>
          <p class="validate-helper"></p>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-no-hp"
            >No.HP</label
          >
          <div class="form-control" id="detail-no-hp">${v.no_hp}</div>
          <p class="validate-helper"></p>
        </div>
      </div>
    `;
    $("#form-detail .modal-body-slider").append(detailStaf);
  });

  handleModal();
};

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleEdit = (target) => {
  const data = $(target).parent().data();
  $("#edit-id").val(data.id);
  $("#edit-status-aktif-surat")
    .val(`${data.status_aktif_surat}`)
    .trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};
