const deleteData = async () => {
  const token = getCookie("act");

  const id = $("#delete-id").val();
  const fd = new FormData();

  fd.append("id", id);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pemeliharaan-kendaraan/delete/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-delete").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(deleteData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
