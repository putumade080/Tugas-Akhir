$(document).ready(() => {

    $("#edit-status-aktif-surat").select2({
      theme: "bootstrap4",
      dropdownParent: $("#modal-edit"),
    });

    loadingDataTable("dataTable");
    getData();
});

const handleDetail = (target) => {
  const data = $(target).parent().data();

  $("#form-detail .modal-body-slider").html("")
  
  data.detail.map((v, i) => {
    const detailKendaraan = `
      <div class="modal-body-item ${i === 0 ? 'active' : ''}">
        <h6 class="h6 font-weight-bold text-primary">
          Detail Pemeliharaan Kendaraan
        </h6>
        <span>Berikut merupakan detail data pemeliharaan kendaraan tersebut</span>
        <p class="mt-1 text-danger"></p>
        <div class="form-group">
          <label class="detail-form" for="detail-kendaraan"
            >Kendaraan</label
          >
          <div class="form-control" id="detail-kendaraan">${v.kendaraan.no_polisi} - ${v.kendaraan.model.merk}</div>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-jenis-kerusakan"
            >Jenis Kerusakan</label
          >
          <div class="form-control" id="detail-jenis-kerusakan">${v.jenis_kerusakan}</div>
          <p class="validate-helper"></p>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-jumlah-kendaraan"
            >Jumlah Kendaraan</label
          >
          <div class="form-control" id="detail-jumlah-kendaraan">${v.jumlah}</div>
          <p class="validate-helper"></p>
        </div>
        <div class="form-group">
          <label class="detail-form" for="detail-keterangan"
            >Keterangan</label
          >
          <div class="form-control" id="detail-keterangan">${v.keterangan}</div>
          <p class="validate-helper"></p>
        </div>
      </div>
    `

    $("#form-detail .modal-body-slider").append(detailKendaraan)
  })

  handleModal()
};

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleEdit = (target) => {
  const data = $(target).parent().data();
  $("#edit-id").val(data.id);
  $("#edit-status-aktif-surat").val(`${data.status_aktif_surat}`).trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};