const updateData = async () => {
  const token = getCookie("act");

  const id = $("#edit-id").val();
  const penanggung_jawab_kendaraan = $(
    "#edit-penanggung-jawab-kendaraan"
  ).val();
  const kendaraan = $("#edit-kendaraan").val();
  const status_aktif_surat = $("#edit-status-aktif-surat").val();
  const fd = new FormData();

  fd.append("id", id);
  fd.append("id_pegawai", penanggung_jawab_kendaraan);
  fd.append("id_kendaraan", kendaraan);
  fd.append("status_aktif_surat", status_aktif_surat);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/berita-acara/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    refreshData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-edit").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(updateData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
