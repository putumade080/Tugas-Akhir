const getPegawai = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pegawai/?status_aktif=true`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    $("#penanggung-jawab-kendaraan").html("<option></option>");
    $("#edit-penanggung-jawab-kendaraan").html("");
    data.map((v) => {
      if (v.role === "Kasubag TU") {
        $("#kasubag-tu").val(`${v.nama} - ${v.nip}`);
        $("#id-kasubag-tu").val(v.id);
      }

      const option = `<option value="${v.id}">${v.nama} - ${v.jabatan}</option>`;
      $("#penanggung-jawab-kendaraan").append(option);
      $("#edit-penanggung-jawab-kendaraan").append(option);
    });
  } else if (status_code === 401) {
    refreshToken(getPegawai);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getPegawai();
    });
  }
};
