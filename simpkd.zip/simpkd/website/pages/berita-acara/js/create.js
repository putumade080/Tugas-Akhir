const createData = async () => {
  const token = getCookie("act");

  const tanggal = $("#tanggal-surat").val();
  const nomor_surat = $("#nomor-surat").val();
  const kasubagTU = $("#id-kasubag-tu").val();
  const penanggung_jawab_kendaraan = $("#penanggung-jawab-kendaraan").val();
  const kendaraan = $("#kendaraan").val();
  const fd = new FormData();

  fd.append("tanggal_surat", tanggal);
  fd.append("no_surat", nomor_surat);
  fd.append("id_kasubag_tu", kasubagTU);
  fd.append("id_pegawai", penanggung_jawab_kendaraan);
  fd.append("id_kendaraan", kendaraan);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/berita-acara/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    refreshData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add").modal("hide");
      $("#modal-add .form-control:not([readonly])").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
