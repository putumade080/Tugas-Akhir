let list_kendaraan = [];

$(document).ready(() => {
  $("#tanggal-surat")
    .datepicker({
      autoclose: true,
      format: "yyyy-mm-dd",
      todayHighlight: true,
      endDate: new Date(),
    })
    .datepicker("setDate", "0");
  $("#edit-tanggal-surat")
    .datepicker({
      autoclose: true,
      format: "yyyy-mm-dd",
      todayHighlight: true,
      endDate: new Date(),
    })
    .datepicker("setDate", "0");
  $("#kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-add"),
    placeholder: "Pilih Kendaraan",
    allowClear: true,
  });
  $("#edit-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#penanggung-jawab-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-add"),
    placeholder: "Pilih Penanggung Jawab Kendaraan",
    allowClear: true,
  });
  $("#edit-penanggung-jawab-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#edit-status-aktif-surat").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  refreshData();
});

const refreshData = () => {
  loadingDataTable("dataTable");
  getData();
  getLetterNum();
  getPegawai();
  getKendaraan();
};

$("#form-add").submit(function (e) {
  e.preventDefault();
  createData();
});

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleEdit = (target) => {
  const data = $(target).parent().data();

  $("#edit-kendaraan").html("");
  list_kendaraan.map(
    (v) =>
      (!v.status_pemakaian || v.id === data.kendaraan.id) &&
      $("#edit-kendaraan").append(
        `<option value="${v.id}">${v.no_polisi} - ${v.model.tipe} - ${v.model.merk}</option>`
      )
  );

  $("#edit-id").val(data.id);
  $("#edit-nomor-surat-penggunaan").val(data.no_surat[0]);
  $("#edit-nomor-surat-serah-terima").val(data.no_surat[1]);
  $("#edit-kasubag-tu").val(`${data.kasubag_tu.nama} - ${data.kasubag_tu.nip}`);
  $("#edit-penanggung-jawab-kendaraan").val(data.pegawai.id).trigger("change");
  $("#edit-kendaraan").val(data.kendaraan.id).trigger("change");
  $("#edit-status-aktif-surat")
    .val(`${data.status_aktif_surat}`)
    .trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};
