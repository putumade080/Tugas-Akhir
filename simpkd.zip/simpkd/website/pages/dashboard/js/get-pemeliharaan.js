const getPemeliharaanKendaraan = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pemeliharaan-kendaraan/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data } = await req.json();

  if (status_code === 200) {
    $("#data-pemeliharaan-kendaraan").html(data.length);
  } else if (status_code === 401) {
    refreshToken(getPemeliharaanKendaraan);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getPemeliharaanKendaraan();
    });
  }
};
