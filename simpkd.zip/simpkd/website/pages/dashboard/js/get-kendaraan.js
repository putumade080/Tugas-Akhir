const months = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];
const prevYear = new Date().getFullYear() - 1;

const getKendaraan = async () => {
  const token = getCookie("act");

  const req = await fetch(`https://simpkd.astungkarasarjana.com/kendaraan/`, {
    headers: {
      "x-auth-token": `Bearer ${token}`,
    },
  });
  const { status_code, data } = await req.json();

  if (status_code === 200) {
    const labels = [...new Set(data.map((v) => v.model.jumlah_roda))];
    const samsatData = data.filter(
      (item) =>
        new Date(new Date().toDateString()) >=
        new Date(
          new Date(item.tgl_samsat_pertama + "T00:00").valueOf() - 604800000
        )
    );
    const kirData = data.filter(
      (item) =>
        new Date(item.tgl_berlaku_kir).toString() !== "Invalid Date" &&
        new Date(new Date().toDateString()) >=
          new Date(
            new Date(item.tgl_berlaku_kir + "T00:00").valueOf() - 604800000
          )
    );

    const today = `${new Date().getFullYear()}-${(new Date().getMonth() + 1)
      .toString()
      .padStart(2, "0")}-${new Date().getDate().toString().padStart(2, "0")}`;

    const samsatTableData = samsatData.map((v, i) => [
      i + 1,
      `<span class="p-2 badge badge-pill ${
        today <= v.tgl_samsat_pertama ? "badge-warning" : "badge-danger"
      }">${
        today <= v.tgl_samsat_pertama ? "Segera Proses" : "Terlambat Proses"
      }</span>`,
      v.no_polisi,
      v.model.tipe,
      v.model.merk,
      v.tgl_samsat_pertama,
      `<div class="d-flex">
            <button
            class="btn btn-success mr-1"
            title="Update Tanggal Samsat Kendaraan"
            onclick="updateSamsat(this)"
            >
            <i class="fas fa-check"></i>
            </button>
          </div>`,
    ]);
    setupFilterDataTable("samsat-datatable", [5], samsatTableData);
    insertDataFilterDataTable("samsat-datatable", samsatData);

    const kirTableData = kirData.map((v, i) => [
      i + 1,
      `<span class="p-2 badge badge-pill ${
        today <= v.tgl_berlaku_kir ? "badge-warning" : "badge-danger"
      }">${
        today <= v.tgl_berlaku_kir ? "Segera Proses" : "Terlambat Proses"
      }</span>`,
      v.no_polisi,
      v.model.tipe,
      v.model.merk,
      v.tgl_berlaku_kir,
      `<div class="d-flex">
            <button
            class="btn btn-success mr-1"
            title="Update Tanggal KIR Kendaraan"
            onclick="updateKir(this)"
            >
            <i class="fas fa-check"></i>
            </button>
          </div>`,
    ]);
    setupFilterDataTable("kir-datatable", [5], kirTableData);
    insertDataFilterDataTable("kir-datatable", kirData);

    const ctx = document.getElementById("chart-jenis-kendaraan");
    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: labels,
        datasets: [
          {
            data: labels.map((l) =>
              data.reduce((r, v) => (v.model.jumlah_roda === l ? r + 1 : r), 0)
            ),
            backgroundColor: [
              "#4e73df",
              "#1cc88a",
              "#36b9cc",
              "#e74a3b",
              "#f6c23e",
            ],
            hoverBackgroundColor: [
              "#2e59d9",
              "#17a673",
              "#2c9faf",
              "#d14133",
              "#e1b23a",
            ],
            hoverBorderColor: "rgba(234, 236, 244, 1)",
          },
        ],
      },
      options: {
        maintainAspectRatio: false,
        tooltips: {
          backgroundColor: "rgb(255,255,255)",
          bodyFontColor: "#858796",
          borderColor: "#dddfeb",
          borderWidth: 1,
          xPadding: 15,
          yPadding: 15,
          displayColors: true,
          caretPadding: 10,
        },
        legend: {
          display: true,
        },
        cutoutPercentage: 80,
      },
    });
  } else if (status_code === 401) {
    refreshToken(getKendaraan);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getKendaraan();
    });
  }
};
