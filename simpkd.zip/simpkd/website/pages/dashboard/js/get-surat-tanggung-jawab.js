const getSuratTanggungJawab = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/surat-tanggung-jawab/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data } = await req.json();

  if (status_code === 200) {
    $("#data-surat-tanggung-jawab").html(data.length);
  } else if (status_code === 401) {
    refreshToken(getSuratTanggungJawab);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getSuratTanggungJawab();
    });
  }
};
