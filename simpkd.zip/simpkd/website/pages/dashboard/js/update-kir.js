const updateKir = async (target) => {
  const data = $(target).parent().data();
  const token = getCookie("act");
  const fd = new FormData();

  fd.append("id", data.id);
  fd.append("no_polisi", data.no_polisi);
  fd.append("id_model", data.model.id);
  fd.append("warna", data.warna);
  fd.append("tgl_samsat_pertama", data.tgl_samsat_pertama);
  fd.append(
    "tgl_berlaku_kir",
    new Date().getFullYear() + 1 + data.tgl_berlaku_kir.slice(4)
  );
  fd.append("harga_perolehan", data.harga_perolehan);
  fd.append("no_stnk", data.no_stnk);
  fd.append("no_bpkb", data.no_bpkb);
  fd.append("no_rangka", data.no_rangka);
  fd.append("no_mesin", data.no_mesin);
  fd.append("no_register_barang", data.no_register_barang);
  fd.append("id_alat_monitoring", data.id_alat_monitoring);
  fd.append("status_pemakaian", data.status_pemakaian);
  fd.append("status_aktif", data.status_aktif);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/kendaraan/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("kir-datatable");
    getKendaraan();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-edit").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(updateKir);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
