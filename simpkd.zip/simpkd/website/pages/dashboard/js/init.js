$(document).ready(async () => {
  loadingDataTable("samsat-datatable");
  loadingDataTable("kir-datatable");
  await getBeritaAcara();
  await getKendaraan();
  await getPemeliharaanKendaraan();
  await getSuratPerintahTugas();
  await getSuratTanggungJawab();
});
