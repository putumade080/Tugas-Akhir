const createData = async () => {
  const token = getCookie("act");

  const no_polisi = $("#no-polisi").val();
  const model = $("#model").val();
  const warna = $("#warna").val();
  const no_register = $("#no-register").val();
  const tanggal_samsat_pertama = $("#tanggal-samsat-pertama").val();
  const tanggal_berlaku_kir = $("#tanggal-berlaku-kir").val();
  const no_stnk = $("#no-stnk").val();
  const no_bpkb = $("#no-bpkb").val();
  const no_rangka = $("#no-rangka").val();
  const no_mesin = $("#no-mesin").val();
  const harga = $("#harga").val();
  const id_alat_monitoring = $("#id-alat-monitoring").val();
  const fd = new FormData();

  fd.append("no_polisi", no_polisi);
  fd.append("id_model", model);
  fd.append("warna", warna);
  fd.append("tgl_samsat_pertama", tanggal_samsat_pertama);
  fd.append("tgl_berlaku_kir", tanggal_berlaku_kir);
  fd.append("harga_perolehan", currencyDeformat(harga));
  fd.append("no_stnk", no_stnk);
  fd.append("no_bpkb", no_bpkb);
  fd.append("no_rangka", no_rangka);
  fd.append("no_mesin", no_mesin);
  fd.append("no_register_barang", no_register);
  fd.append("id_alat_monitoring", id_alat_monitoring);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/kendaraan/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add").modal("hide");
      $("#modal-add .form-control").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};

const createNews = async () => {
  const token = getCookie("act");

  const tanggal = $("#tanggal-surat-berita-acara").val();
  const nomor_surat = $("#nomor-surat-berita-acara").val();
  const kasubagTU = $("#id-kasubag-tu-berita-acara").val();
  const kendaraan = $("#id-kendaraan-berita-acara").val();
  const penanggung_jawab_kendaraan = $("#penanggung-jawab-kendaraan-berita-acara").val();
  const fd = new FormData();

  fd.append("tanggal_surat", tanggal);
  fd.append("no_surat", nomor_surat);
  fd.append("id_kasubag_tu", kasubagTU);
  fd.append("id_pegawai", penanggung_jawab_kendaraan);
  fd.append("id_kendaraan", kendaraan);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/berita-acara/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    refreshData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add-berita-acara").modal("hide");
      $("#modal-add-berita-acara .form-control:not([readonly])").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createNews);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};