const getPdfData = async () => {
  const token = getCookie("act");
  const params = new URLSearchParams(window.location.search);

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/kendaraan/get/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    console.log(data);
    objectToPdfData(data);
    formatPdfData();
  } else if (status_code === 401) {
    refreshToken(getPdfData);
  } else {
    document.body.innerHTML = "PDF tidak dapat ditampilkan";
  }
};

getPdfData();
