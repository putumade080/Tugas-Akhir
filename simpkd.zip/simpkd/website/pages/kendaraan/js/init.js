$(document).ready(() => {
    $("#tanggal-surat-berita-acara").datepicker({
      autoclose: true,
      format: "yyyy-mm-dd",
      todayHighlight: true,
      endDate: new Date(),
    }).datepicker("setDate", "0");
  $("#tanggal-samsat-pertama").datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    startDate: new Date(),
  });
  $("#edit-tanggal-samsat-pertama").datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    startDate: new Date(),
  });
  $("#tanggal-berlaku-kir").datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    endDate: new Date(),
  });
  
  $("#edit-tanggal-berlaku-kir").datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    endDate: new Date(),
  });
  
  $("#model").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-add"),
    placeholder: "Pilih Model Kendaraan",
    allowClear: true,
  });
  $("#penanggung-jawab-kendaraan-berita-acara").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-add-berita-acara"),
    placeholder: "Pilih Penanggung Jawab Kendaraan",
    allowClear: true,
  });
  $("#edit-model").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#edit-status-kendaraan").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#edit-status-aktif").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });
  $("#edit-status-pemakaian").select2({
    theme: "bootstrap4",
    dropdownParent: $("#modal-edit"),
  });

  $("#harga").keyup(function () {
    $(this).val(currencyFormat($(this).val()));
  });

  $("#edit-harga").keyup(function () {
    $(this).val(currencyFormat($(this).val()));
  });

  refreshData()
});

const refreshData = () => {
  loadingDataTable("dataTable");
  getModel();
  getData();
  getNewsLetterNum();
  getPegawai();
};

$("#form-add").submit(function (e) {
  e.preventDefault();
  createData();
});

$("#form-add-berita-acara").submit(function (e) {
  e.preventDefault();
  createNews();
});

$("#form-edit").submit(function (e) {
  e.preventDefault();
  updateData();
});

$("#form-delete").submit(function (e) {
  e.preventDefault();
  deleteData();
});

const handleCreateNews = (target) => {
    const data = $(target).parent().data();
    $("#id-kendaraan-berita-acara").val(data.id)
    $("#kendaraan-berita-acara").val(`${data.no_polisi} - ${data.model.tipe} - ${data.model.merk}`)
}

const handleDetail = (target) => {
  const data = $(target).parent().data();
  $("#detail-no-polisi").html(data.no_polisi);
  $("#detail-model").html(
    `${data.model.tipe} - ${data.model.merk} - Roda ${data.model.jumlah_roda}`
  );
  $("#detail-warna").html(data.warna);
  $("#detail-no-register").html(data.no_register_barang);
  $("#detail-tanggal-samsat-pertama").html(data.tgl_samsat_pertama);
  $("#detail-tanggal-berlaku-kir").html(data.tgl_berlaku_kir);
  $("#detail-no-stnk").html(data.no_stnk);
  $("#detail-no-bpkb").html(data.no_bpkb);
  $("#detail-no-rangka").html(data.no_rangka);
  $("#detail-no-mesin").html(data.no_mesin);
  $("#detail-harga").html(currencyFormat(data.harga_perolehan));
  $("#detail-status-kendaraan").html(
    data.status_pemakaian ? "Tidak Tersedia" : "Tersedia"
  );
  $("#detail-status-aktif").html(data.status_aktif ? "Aktif" : "Nonaktif");
};

const handleEdit = (target) => {
  const data = $(target).parent().data();
  $("#edit-id").val(data.id);
  $("#edit-no-polisi").val(data.no_polisi);
  $("#edit-model").val(data.model.id).trigger("change");
  $("#edit-warna").val(data.warna);
  $("#edit-no-register").val(data.no_register_barang);
  $("#edit-tanggal-samsat-pertama").val(data.tgl_samsat_pertama);
  $("#edit-tanggal-berlaku-kir").val(data.tgl_berlaku_kir);
  $("#edit-no-stnk").val(data.no_stnk);
  $("#edit-no-bpkb").val(data.no_bpkb);
  $("#edit-no-rangka").val(data.no_rangka);
  $("#edit-no-mesin").val(data.no_mesin);
  $("#edit-harga").val(currencyFormat(data.harga_perolehan));
  $("#edit-id-alat-monitoring").val(data.id_alat_monitoring);
  $("#edit-status-kendaraan").val(`${data.status_pemakaian}`).trigger("change");
  $("#edit-status-aktif").val(`${data.status_aktif}`).trigger("change");
};

const handleDelete = (target) => {
  const data = $(target).parent().data();
  $("#delete-id").val(data.id);
};
