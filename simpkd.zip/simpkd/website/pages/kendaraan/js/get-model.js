const getModel = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/model-kendaraan/?status_aktif=true`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    $("#model").html("<option></option>");
    $("#edit-model").html("");
    data.map((v) => {
      const option = `<option value="${v.id}">${v.tipe} - ${v.merk} - Roda ${v.jumlah_roda}</option>`;
      $("#model").append(option);
      $("#edit-model").append(option);
    });
  } else if (status_code === 401) {
    refreshToken(getModel);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getModel();
    });
  }
};
