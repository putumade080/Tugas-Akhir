const updateData = async () => {
  const token = getCookie("act");

  const id = $("#edit-id").val();
  const no_polisi = $("#edit-no-polisi").val();
  const model = $("#edit-model").val();
  const warna = $("#edit-warna").val();
  const no_register = $("#edit-no-register").val();
  const tanggal_samsat_pertama = $("#edit-tanggal-samsat-pertama").val();
  const tanggal_berlaku_kir = $("#edit-tanggal-berlaku-kir").val();
  const no_stnk = $("#edit-no-stnk").val();
  const no_bpkb = $("#edit-no-bpkb").val();
  const no_rangka = $("#edit-no-rangka").val();
  const no_mesin = $("#edit-no-mesin").val();
  const harga = $("#edit-harga").val();
  const id_alat_monitoring = $("#edit-id-alat-monitoring").val();
  const status_kendaraan = $("#edit-status-kendaraan").val();
  const status_aktif = $("#edit-status-aktif").val();
  const fd = new FormData();

  fd.append("id", id);
  fd.append("no_polisi", no_polisi);
  fd.append("id_model", model);
  fd.append("warna", warna);
  fd.append("tgl_samsat_pertama", tanggal_samsat_pertama);
  fd.append("tgl_berlaku_kir", tanggal_berlaku_kir);
  fd.append("harga_perolehan", currencyDeformat(harga));
  fd.append("no_stnk", no_stnk);
  fd.append("no_bpkb", no_bpkb);
  fd.append("no_rangka", no_rangka);
  fd.append("no_mesin", no_mesin);
  fd.append("no_register_barang", no_register);
  fd.append("id_alat_monitoring", id_alat_monitoring);
  fd.append("status_pemakaian", status_kendaraan);
  fd.append("status_aktif", status_aktif);

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/kendaraan/update/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    loadingDataTable("dataTable");
    getData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-edit").modal("hide");
    });
  } else if (status_code === 401) {
    refreshToken(updateData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
