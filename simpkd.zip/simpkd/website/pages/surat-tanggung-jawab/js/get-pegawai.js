const getPegawai = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/pegawai/?status_aktif=true`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    $("#pemberi-tanggung-jawab").html("<option></option>");
    $("#edit-pemberi-tanggung-jawab").html("");
    $("#penerima-tanggung-jawab").html("<option></option>");
    $("#edit-penerima-tanggung-jawab").html("");
    data.map((v) => {
      const option = `<option value="${v.id}">${v.nama} - ${v.jabatan}</option>`;
      $("#pemberi-tanggung-jawab").append(option);
      $("#edit-pemberi-tanggung-jawab").append(option);
      $("#penerima-tanggung-jawab").append(option);
      $("#edit-penerima-tanggung-jawab").append(option);
    });
  } else if (status_code === 401) {
    refreshToken(getPegawai);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getPegawai();
    });
  }
};
