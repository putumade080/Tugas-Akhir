const statuses = ["Menunggu Konfirmasi", "Diterima", "Ditolak"];
const statusBadges = ["badge-warning", "badge-success", "badge-danger"];

const getData = async () => {
  const token = getCookie("act");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/surat-tanggung-jawab/`,
    {
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    const tableData = data.map((v, i) => [
      i + 1,
      v.no_surat,
      v.tanggal_surat,
      v.pemberi.nama,
      v.penerima.nama,
      v.admin.nama,
      v.kendaraan.map((obj) => obj.no_polisi).join(", "),
      `<span class="p-2 badge badge-pill ${statusBadges[v.status_pemberi]}">${
        statuses[v.status_pemberi]
      }</span>`,
      `<span class="p-2 badge badge-pill ${statusBadges[v.status_penerima]}">${
        statuses[v.status_penerima]
      }</span>`,
      `<span class="p-2 badge badge-pill ${
        v.status_aktif_surat ? "badge-success" : "badge-danger"
      }">${v.status_aktif_surat ? "Aktif" : "Nonaktif"}</span>`,
      `<div class="d-flex">
          <button
            class="btn btn-warning mr-1"
            title="Edit Data Surat Tanggung Jawab"
            data-toggle="modal"
            data-target="#modal-edit"
            onclick="handleEdit(this)"
          >
            <i class="fas fa-edit"></i>
            </button>
            <button
            class="btn btn-danger mr-1"
            title="Non-Aktif Surat Tanggung Jawab"
            data-toggle="modal"
            data-target="#modal-delete"
            onclick="handleDelete(this)"
          >
            <i class="fas fa-file-export"></i>
          </button>
          <a
            class="btn btn-dark"
            title="Print Surat Perintah Tugas"
            href="${window.location.href}/pdf?id=${v.id}"
            >
            <i class="fas fa-print"></i>
            </a>
        </div>`,
    ]);
    setupFilterDataTable("dataTable", [10], tableData);
    insertDataFilterDataTable("dataTable", data);
  } else if (status_code === 401) {
    refreshToken(getData);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getData();
    });
  }
};
