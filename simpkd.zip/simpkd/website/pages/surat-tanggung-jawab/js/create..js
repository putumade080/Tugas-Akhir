const createData = async () => {
  const token = getCookie("act");

  const no_surat = $("#nomor-surat").val();
  const tanggal = $("#tanggal-surat").val();
  const pemberi = $("#pemberi-tanggung-jawab").val();
  const penerima = $("#penerima-tanggung-jawab").val();
  const kendaraan = $("#kendaraan").val();
  const fd = new FormData();

  fd.append("no_surat", no_surat);
  fd.append("tanggal_surat", tanggal);
  fd.append("id_pemberi", pemberi);
  fd.append("id_penerima", penerima);
  fd.append("id_kendaraan", JSON.stringify(kendaraan));

  showLoading();

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/surat-tanggung-jawab/create/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
      body: fd,
    }
  );
  const { status_code, message } = await req.json();

  if (status_code === 200) {
    refreshData();

    hideLoading();
    Swal.fire({
      title: "Berhasil",
      text: message,
      icon: "success",
      confirmButtonText: "Tutup",
    }).then(() => {
      $("#modal-add").modal("hide");
      $("#modal-add .form-control:not([readonly])").val("");
    });
  } else if (status_code === 401) {
    refreshToken(createData);
  } else {
    hideLoading();
    Swal.fire({
      title: `Error ${status_code}`,
      text: message,
      icon: status_code === 400 ? "warning" : "error",
      confirmButtonText: "Tutup",
    });
  }
};
