const refreshToken = async (callback, retry = 0, maxRetry = 3) => {
  const token = getCookie("rft");

  const req = await fetch(
    `https://simpkd.astungkarasarjana.com/token/refresh/`,
    {
      method: "POST",
      headers: {
        "x-auth-token": `Bearer ${token}`,
      },
    }
  );
  const { status_code, data, message } = await req.json();

  if (status_code === 200) {
    document.cookie = `act=${data.access_token}; path=/`;
    document.cookie = `rft=${data.refresh_token}; path=/`;
    callback();
  } else if (status_code === 401) {
    removeCookie("act");
    removeCookie("rft");
    Swal.fire({
      title: "Sesi Berakhir",
      text: "Sesi akun Anda telah berakhir, mohon lakukan proses login kembali",
      icon: "warning",
      confirmButtonText: "Login Ulang",
    }).then(() => {
      window.location.href = "/website/pages/login/";
    });
  } else {
    if (retry === maxRetry) {
      Swal.fire({
        title: "Terjadi kesalahan",
        text: message,
        icon: "error",
        confirmButtonText: "Tutup",
      });
    } else {
      refreshToken(callback, retry + 1);
    }
  }
};
