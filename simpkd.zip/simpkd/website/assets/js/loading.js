const showLoading = () => {
  $(".loading-wrapper").addClass("show");
};

const hideLoading = () => {
  $(".loading-wrapper").removeClass("show");
};
