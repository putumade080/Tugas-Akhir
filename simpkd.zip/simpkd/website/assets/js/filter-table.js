const removeHTMLTags = (str) => {
  return str.replace(/<[^>]*>/g, "");
};

const loadingDataTable = (id) => {
  const table = $(`#${id}`).DataTable({
    destroy: true,
    ordering: false,
    searching: false,
    paging: false,
  });
  const colLength = $(`#${id} thead tr:first-child th`).length;

  table.clear().draw();
  $(`#${id} thead tr:eq(1)`).remove();
  $(`#${id} tbody tr:first-child`).remove();
  $(`#${id} tbody`).append(`
    <tr>
      <td class="text-center" colspan="${colLength}">
        <div class="my-3">
          <div class="spinner-border text-secondary" role="status" style="height: 2.5rem; width: 2.5rem;">
            <span class="sr-only">Loading...</span>
          </div>
          <h6 class="h6 mt-2">Mohon tunggu, sedang memuat data...</h6>
        </div>
      </td>
    </tr>
  `);
};

const setupFilterDataTable = (id, unorderableCols, tableData) => {
  if ($(`#${id} thead tr`).length === 1) {
    $(`#${id} thead tr`).clone(true).appendTo(`#${id} thead`);
  }

  $(`#${id} thead tr:eq(1) th`).each(function (i) {
    const title = $(`#${id} thead tr:eq(0) th:eq(${i})`).text();
    const type = $(this).data("type");

    if (!type) {
      $(this).removeClass();
      $(this).html("");
      return;
    }

    if (type === "select") {
      const colData = [
        ...new Set(Array.from(tableData.map((v) => removeHTMLTags(`${v[i]}`)))),
      ];
      $(this).html(
        `<select class='form-control'><option value=''>Pilih ${title}</option></select>`
      );
      colData.map((v) =>
        $("select", this).append(
          `<option style="text-transform: capitalize" value="${v}">${v}</option>`
        )
      );
      $("select", this).on("change", function () {
        if (table.column(i).search() !== this.value) {
          table.column(i).search(this.value).draw();
        }
      });
    } else {
      $(this).html(
        `<input type="${type}" class="form-control" placeholder="Filter ${title}" />`
      );
      $("input", this).on("keyup change", function () {
        if (table.column(i).search() !== this.value) {
          table.column(i).search(this.value).draw();
        }
      });
    }
  });

  const table = $(`#${id}`).DataTable({
    destroy: true,
    orderCellsTop: true,
    fixedHeader: true,
    columnDefs: [
      {
        orderable: false,
        targets: unorderableCols,
      },
    ],
    data: tableData,
  });
};

const insertDataFilterDataTable = (id, data) => {
  const table = $(`#${id}`).DataTable();
  const cols = $(`#${id} thead th`).length;

  table.rows().every(function(rowIdx) {
    $(this.node()).find("td > div").data(data[rowIdx])
  })
}