const currencyFormat = (number) => {
  const currency = Number(String(number).replace(/[^\d]/g, "")).toLocaleString(
    "ID",
    {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }
  );
  return currency.replace(/\s/g, "");
};

const currencyDeformat = (money) => {
  return money.replace(/[^\d]/g, "");
};
