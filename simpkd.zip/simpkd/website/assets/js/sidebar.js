let me = {};

const getSidebarData = async () => {
  const token = getCookie("act");

  const req = await fetch(`https://simpkd.astungkarasarjana.com/profile/`, {
    headers: {
      "x-auth-token": `Bearer ${token}`,
    },
  });
  const { status_code, data } = await req.json();

  if (status_code === 200) {
    me = data;
    $("#nama-user").html(me.nama);
    if (me.foto_profil) $("#foto-user").attr("src", me.foto_profil);
  } else if (status_code === 401) {
    refreshToken(getSidebarData);
  } else {
    Swal.fire({
      title: `Error ${status_code}`,
      text: "Terjadi kesalahan, silahkan tekan tombol Muat Ulang beberapa saat lagi untuk mencoba kembali",
      icon: "error",
      confirmButtonText: "Muat Ulang",
    }).then(() => {
      getSidebarData();
    });
  }
};

$(document).ready(async () => {
  await getSidebarData();
});
