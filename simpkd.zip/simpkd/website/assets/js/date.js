const dateFormat = (date) => {
  const months = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember",
  ];
  const items = date.split("-");
  return `${items[2]} ${months[Number(items[1]) - 1]} ${items[0]}`;
};
