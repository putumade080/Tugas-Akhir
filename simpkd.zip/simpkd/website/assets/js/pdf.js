const mapToPdfData = (data, parents = []) => {
  parent = parents.join(".").replace(".[", "[");
  $(`[data-array = '${parent}']`).map((_, el) => {
    data.slice(1).map((_, j) => {
      const newItem = $(el).clone();
      newItem.removeAttr("data-array");
      newItem.insertAfter($(el));
      newItem.find($(`[data-array-index = '${parent}']`)).map((_, child) => {
        if (child.tagName === "OL") {
          $(child).attr("start", data.length - j);
        } else if (!$(child).attr("data-index-hide")) {
          $(child).html(data.length - j);
        }

        if (Number($(child).attr("data-index-hide")) === j + 1) {
          $(child).html("");
        }
      });
      newItem.find($(`[data-array-parent = '${parent}']`)).map((_, child) => {
        const pdfData = $(child).attr("data-pdf");
        $(child).attr(
          "data-pdf",
          `${parent}[${data.length - (j + 1)}].${pdfData}`
        );
      });
    });
    $(el)
      .find($(`[data-array-index = '${parent}']`))
      .map((_, child) => {
        if (child.tagName === "OL") {
          $(child).attr("start", 1);
        } else if (!$(child).attr("data-index-hide")) {
          $(child).html(1);
        }

        if (Number($(child).attr("data-index-hide")) === 0) {
          $(child).html("");
        }
      });
    $(el)
      .find($(`[data-array-parent = '${parent}']`))
      .map((_, child) => {
        const pdfData = $(child).attr("data-pdf");
        $(child).attr("data-pdf", `${parent}[0].${pdfData}`);
      });
  });
};

const objectToPdfData = (data, parents = []) => {
  parent = parents.join(".").replace(".[", "[");
  if (!data) {
    $(`[data-pdf = '${parent}']`).html("-");
  } else if (typeof data !== "object") {
    $(`[data-pdf = '${parent}']`).html(data);
  } else if (Array.isArray(data)) {
    mapToPdfData(data, parents);
    data.map((item, i) => {
      objectToPdfData(item, [...parents, `[${i}]`]);
    });
  } else {
    Object.entries(data).map((item) => {
      objectToPdfData(item[1], [...parents, item[0]]);
    });
  }
};

const formatPdfData = () => {
  if ($(`[data-pdf-format = 'currency']`).length > 0) {
    $(`[data-pdf-format = 'currency']`).html(
      currencyFormat($(`[data-pdf-format = 'currency']`).html())
    );
  }
  if ($(`[data-pdf-format = 'date']`).length > 0) {
    $(`[data-pdf-format = 'date']`).html(
      dateFormat($(`[data-pdf-format = 'date']`).html())
    );
  }
};
