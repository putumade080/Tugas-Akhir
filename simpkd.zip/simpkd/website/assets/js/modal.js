const handleModalButton = (slider, prevButton, nextButton) => {
  const itemLength = slider.children().length;
  const type = $(slider).data("type");

  if (itemLength === 1) {
    if (type === "detail") {
      prevButton.text("Tutup");
      nextButton.css("display", "none");
    } else {
      prevButton.text("Batal");
      nextButton.text("Simpan");
      nextButton.prop("type", "submit");
    }
  } else if (slider.children(".active").index() === itemLength - 1) {
    if (type === "detail") {
      nextButton.text("Tutup");
      nextButton.prop("type", "button");
    } else if (type === "submit") {
      nextButton.text("Submit");
      nextButton.prop("type", "submit");
    } else {
      nextButton.text("Simpan");
      nextButton.prop("type", "submit");
    }
    prevButton.text("Sebelumnya");
  } else if (slider.children(".active").index() === 0) {
    prevButton.text(type === "detail" ? "Tutup" : "Batal");
    nextButton.text("Selanjutnya");
    nextButton.prop("type", "button");
    nextButton.css("display", "");
  } else {
    prevButton.text("Sebelumnya");
    nextButton.text("Selanjutnya");
    nextButton.prop("type", "button");
  }
};

const handleModal = () => {
  $(".modal-content").each(function () {
    const modal = $(this);
    const body = modal.children(".modal-body");
    if (body.children(".modal-body-slider").length > 0) {
      const footer = modal.children(".modal-footer");
      const prevButton = footer.children(".btn-secondary");
      const nextButton = footer.children(".btn-primary");
      const slider = body.children(".modal-body-slider");
      const itemLength = slider.children().length;

      slider.css("width", `${itemLength * 100}%`);
      handleModalButton(slider, prevButton, nextButton);

      prevButton.off("click");
      nextButton.off("click");

      $(prevButton).on("click", function () {
        const activeIndex = slider.children(".active").index();
        if (activeIndex > 0) {
          slider.css(
            "transform",
            `translateX(${(-100 / itemLength) * (activeIndex - 1)}%)`
          );
          $(slider.children()[activeIndex]).removeClass("active");
          $(slider.children()[activeIndex - 1]).addClass("active");
          handleModalButton(slider, prevButton, nextButton);
        } else {
          const modal = slider.parents(".modal");
          modal.modal("hide");
        }
      });

      $(nextButton).on("click", function (e) {
        const activeIndex = slider.children(".active").index();
        let isEmpty = false;

        $(slider.children(".active").children(".form-group")).each(function () {
          $(this).children(".form-control").blur();
          if (
            $(this).children(".validate-helper").length > 0 &&
            $(this).children(".validate-helper").text()
          ) {
            e.preventDefault();
            Swal.fire({
              title: "Peringatan",
              text: "Mohon lengkapi semua kolom dengan data yang benar",
              icon: "warning",
              confirmButtonText: "Tutup",
            });
            isEmpty = true;
            return;
          }
        });

        if (isEmpty) {
          return;
        }

        if (activeIndex < slider.children().length - 1) {
          e.preventDefault();
          slider.css(
            "transform",
            `translateX(${(-100 / itemLength) * (activeIndex + 1)}%)`
          );
          $(slider.children()[activeIndex]).removeClass("active");
          $(slider.children()[activeIndex + 1]).addClass("active");
          handleModalButton(slider, prevButton, nextButton);
        } else {
          const type = $(slider).data("type");

          if (type === "detail" && e.target.innerText === "Tutup") {
            const modal = slider.parents(".modal");
            modal.modal("hide");
          }
        }
      });

      slider.parents(".modal").on("hidden.bs.modal", function () {
        slider.css("transform", "");
        slider.children().removeClass("active");
        $(slider.children()[0]).addClass("active");
        handleModalButton(slider, prevButton, nextButton);
      });
    }
  });
};

$(document).ready(() => {
  handleModal();
});
