const getCookie = (name) => {
  const cookies = document.cookie.split("; ");
  const cookie = cookies.reduce((r, v) => (v.includes(name) ? v : r), "");

  return cookie ? cookie.split("=")[1] : "";
};

const removeCookie = (name) => {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/`;
};
