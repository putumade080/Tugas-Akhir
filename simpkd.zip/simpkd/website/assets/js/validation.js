$(document).ready(() => {
  $(".validate-number").keydown((e) => {
    if (
      (e.keyCode < 48 || e.keyCode > 57) &&
      (e.keyCode < 96 || e.keyCode > 105) &&
      (e.keyCode < 37 || e.keyCode > 40) &&
      ![8, 9, 13, 46].includes(e.keyCode)
    ) {
      e.preventDefault();
    }
  });

  $(".validate-required").each(function () {
    $(this)
      .siblings(".validate-label")
      .html(
        $(this).siblings(".validate-label").text() +
          ` <span class="text-danger">*</span>`
      );
  });

  $(".validate-required").blur(function () {
    if (
      (typeof $(this).val() === "object" && $(this).val().length > 0) ||
      (typeof $(this).val() === "string" && $(this).val().trim())
    ) {
      $(this).siblings(".validate-helper").text("");
      $(this).parent().css("margin-bottom", "1rem");
    } else {
      $(this).siblings(".validate-helper").text("Kolom ini tidak boleh kosong");
      $(this).parent().css("margin-bottom", "2.5rem");
    }
  });

  $(".validate-nip").blur(function () {
    if ($(this).val().length === 0 || $(this).val().length === 18) {
      $(this).siblings(".validate-helper").text("");
      $(this).parent().css("margin-bottom", "1rem");
    } else {
      $(this)
        .siblings(".validate-helper")
        .text("NIP harus terdiri dari 18 angka");
      $(this).parent().css("margin-bottom", "2.5rem");
    }
  });

  $(".validate-nik").blur(function () {
    if ($(this).val().length === 16) {
      $(this).siblings(".validate-helper").text("");
      $(this).parent().css("margin-bottom", "1rem");
    } else {
      $(this)
        .siblings(".validate-helper")
        .text("NIK harus terdiri dari 16 angka");
      $(this).parent().css("margin-bottom", "2.5rem");
    }
  });

  $(".validate-phone").blur(function () {
    if ($(this).val().length >= 10 && $(this).val().length <= 13) {
      $(this).siblings(".validate-helper").text("");
      $(this).parent().css("margin-bottom", "1rem");
    } else {
      $(this)
        .siblings(".validate-helper")
        .text("No. HP harus terdiri dari 10-13 angka");
      $(this).parent().css("margin-bottom", "2.5rem");
    }
  });

  $(".validate-email").blur(function () {
    if (
      $(this)
        .val()
        .match(
          /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
        )
    ) {
      $(this).siblings(".validate-helper").text("");
      $(this).parent().css("margin-bottom", "1rem");
    } else {
      $(this).siblings(".validate-helper").text("Alamat e-mail tidak valid");
      $(this).parent().css("margin-bottom", "2.5rem");
    }
  });

  $(".password-toggle").each(function () {
    $(this).css("padding-right", "3rem");
    $(this)
      .parent()
      .append(
        "<button type='button' class='btn btn-password-toggle'><i class='fas fa-eye-slash' /></button>"
      );
    $(this)
      .siblings(".btn-password-toggle")
      .click(() => {
        if ($(this).prop("type") === "password") {
          $(this).prop("type", "text");
          $(this)
            .siblings(".btn-password-toggle")
            .children("i")
            .removeClass("fa-eye-slash");
          $(this)
            .siblings(".btn-password-toggle")
            .children("i")
            .addClass("fa-eye");
        } else {
          $(this).prop("type", "password");
          $(this)
            .siblings(".btn-password-toggle")
            .children("i")
            .removeClass("fa-eye");
          $(this)
            .siblings(".btn-password-toggle")
            .children("i")
            .addClass("fa-eye-slash");
        }
      });
  });
});
