<?php
    define("HOST", "localhost");
    define("USER", "astq3554_simpkd");
    define("PASSWORD", "astq3554_simpkd");
    define("DB", "astq3554_simpkd");

    function connect_db() {
        $mysqli = new mysqli(HOST, USER, PASSWORD, DB);

        if ($mysqli->connect_errno) {
            echo "Failed to connect to Database: $mysqli->connect_error";
            exit();
        }

        return $mysqli;
    }